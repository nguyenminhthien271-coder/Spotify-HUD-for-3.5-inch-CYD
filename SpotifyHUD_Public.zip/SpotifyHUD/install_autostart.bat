@echo off
rem Makes the helper start by itself every time you log in, and starts it now.
python "%~dp0spotify_helper.py" --install
start "" pythonw "%~dp0spotify_helper.py"
pause
