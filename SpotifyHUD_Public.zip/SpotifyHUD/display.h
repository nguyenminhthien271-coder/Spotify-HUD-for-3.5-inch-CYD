// Screen + touch setup for the Freenove FNK0104N (3.5", ST77922), in LANDSCAPE (480 x 320).
// Based on Freenove's Sketch_16.1 display code, with rotation done in software.
#ifndef __DISPLAY_H
#define __DISPLAY_H

#include "lvgl.h"
#include "Arduino.h"
#include "TFT_eSPI.h"   // also loads the FNK0104N screen settings

// Screen upside down? Change 0 to 1 and upload again.
#define FLIP_SCREEN 0

#define SCREEN_W 480   // landscape width
#define SCREEN_H 320   // landscape height

class Display
{
public:
    void init();
    void routine();

    // Screen sleep: fades the backlight off / on.
    void sleep();
    void wake();
    bool sleeping();
    void setBrightness(uint8_t level);   // 0-255, used when awake
    unsigned long lastTouchMs();         // when the screen was last touched (millis)
};

#endif
