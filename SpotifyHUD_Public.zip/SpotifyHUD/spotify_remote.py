"""
Presses buttons in the Spotify app for you (Windows only), so the board can start a
playlist or a specific song. It uses Windows' accessibility system (the same thing
screen readers use) - no Spotify account access needed, works on the free plan.

How it works:
  - Start a playlist: open it in Spotify, then press its big green Play button.
  - Start a song:     open the playlist with that song highlighted (which scrolls to it),
                      then press the song's own Play button.
  - Read a playlist:  open it, scroll through it and note every song (for playlists with
                      more than 100 songs - Spotify's public page only lists the first 100).

It runs in its own background thread so the board keeps updating while it works.
"""

import ctypes
import ctypes.wintypes as wt
import os
import queue
import re
import threading
import time

WAIT_FOR_BUTTON = 8.0   # seconds to wait for Spotify to show the button
READ_TIME_LIMIT = 120   # give up reading one playlist after this many seconds
TRACK_ID = re.compile(r"track[/:]([A-Za-z0-9]{22})")


class SpotifyRemote:
    def __init__(self):
        self.jobs = queue.Queue()
        self.available = True
        self.volume = {"pc": -1, "spotify": -1}   # 0-100, or -1 if unknown
        threading.Thread(target=self._worker, daemon=True).start()

    def like_current_song(self, on_done):
        """Press "Add to playlist" in Spotify's bottom bar (saves to Liked Songs).
        on_done(result) is called with "added", "already" or "failed"."""
        self.jobs.put(("like", on_done))

    def set_volume(self, target, percent):
        """target: "pc" (whole computer) or "spotify" (just Spotify, in the Windows mixer)."""
        self.jobs.put(("volume", target, percent))

    # ---------- called from the helper ----------

    def play_playlist(self, playlist_id, names, first_track=None):
        """names: possible names of the playlist's Play button (e.g. ["Chill mix"])."""
        self.jobs.put(("playlist", playlist_id, names, first_track))

    def play_song(self, playlist_id, track):
        """track: dict with "title", "subtitle" (artist) and "uri" from the playlist's song list."""
        self.jobs.put(("song", playlist_id, track))

    def read_playlist(self, playlist_id, names, on_done):
        """Read every song of a playlist from the Spotify app. on_done(songs or None)."""
        self.jobs.put(("read", playlist_id, names, on_done))

    @staticmethod
    def spotify_open():
        return bool(spotify_windows())

    # ---------- background thread ----------

    def _worker(self):
        try:
            import warnings
            warnings.filterwarnings("ignore", category=FutureWarning)   # harmless "Python 3.15" note
            import comtypes
            import comtypes.client
            # Windows needs COM switched on in this thread. Importing comtypes usually does it
            # already; if so, Windows says "already set" and that's fine.
            try:
                comtypes.CoInitialize()
            except OSError:
                pass
            comtypes.client.GetModule("UIAutomationCore.dll")
            from comtypes.gen import UIAutomationClient as U
            self.U = U
            self.uia = comtypes.client.CreateObject(U.CUIAutomation, interface=U.IUIAutomation)
        except Exception as e:
            self.available = False
            print(f"  (can't press Spotify's buttons - run 'python -m pip install comtypes'. Details: {e})")
            print("  Playlists will open in Spotify, but you'll need to press play yourself.")

        last_volume_read = 0.0
        while True:
            try:
                job = self.jobs.get(timeout=0.5)
            except queue.Empty:
                job = None
            try:
                if job is None:
                    pass
                elif job[0] == "playlist":
                    self._do_playlist(*job[1:])
                elif job[0] == "song":
                    self._do_song(*job[1:])
                elif job[0] == "read":
                    songs = None
                    try:
                        songs = self._do_read(*job[1:3]) if self.available else None
                    except Exception as e:
                        print(f"  (couldn't read the playlist from Spotify: {type(e).__name__} {e})")
                    job[3](songs)
                elif job[0] == "like":
                    job[1](self._do_like())
                elif job[0] == "volume":
                    # Only the newest volume change matters - skip older ones still waiting.
                    while not self.jobs.empty() and self.jobs.queue[0][0] == "volume":
                        job = self.jobs.get()
                    self._set_volume(*job[1:])
                    last_volume_read = 0.0
            except Exception as e:
                print(f"  (Spotify / volume problem: {type(e).__name__} {e})")
            if time.time() - last_volume_read > 1.0:
                last_volume_read = time.time()
                self._read_volume()

    # ---------- volume (uses pycaw) ----------

    def _pc_volume_control(self):
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        speakers = AudioUtilities.GetSpeakers()
        if hasattr(speakers, "EndpointVolume"):        # newer pycaw
            return speakers.EndpointVolume
        from ctypes import POINTER, cast
        import comtypes
        iface = speakers.Activate(IAudioEndpointVolume._iid_, comtypes.CLSCTX_ALL, None)   # older pycaw
        return cast(iface, POINTER(IAudioEndpointVolume))

    def _spotify_volume_controls(self):
        from pycaw.pycaw import AudioUtilities
        controls = []
        for session in AudioUtilities.GetAllSessions():
            try:
                if session.Process and session.Process.name().lower() == "spotify.exe":
                    controls.append(session.SimpleAudioVolume)
            except Exception:
                pass
        return controls

    def _read_volume(self):
        try:
            self.volume["pc"] = round(self._pc_volume_control().GetMasterVolumeLevelScalar() * 100)
        except Exception:
            self.volume["pc"] = -1
        try:
            controls = self._spotify_volume_controls()
            self.volume["spotify"] = round(controls[0].GetMasterVolume() * 100) if controls else -1
        except Exception:
            self.volume["spotify"] = -1

    def _set_volume(self, target, percent):
        level = max(0, min(100, percent)) / 100
        if target == "pc":
            self._pc_volume_control().SetMasterVolumeLevelScalar(level, None)
        else:
            for control in self._spotify_volume_controls():
                control.SetMasterVolume(level, None)

    def _do_playlist(self, playlist_id, names, first_track):
        os.startfile("spotify:playlist:" + playlist_id)
        if not self.available:
            return
        wanted = {("play " + n).lower() for n in names if n}
        start = time.time()
        while time.time() - start < WAIT_FOR_BUTTON:
            for name, button in self._play_buttons():
                if name.lower() in wanted:
                    self._press(button)
                    print(f"  started playlist ({name})")
                    return
            # Backup plan after a few seconds: press Play on the first song instead.
            if first_track and time.time() - start > 3.5:
                button = self._song_button(first_track)
                if button:
                    self._press(button)
                    print("  started playlist from its first song")
                    return
            time.sleep(0.4)
        print("  (Spotify opened the playlist, but I couldn't find its Play button)")

    def _do_song(self, playlist_id, track):
        if not track.get("uri"):
            return self._do_song_by_scrolling(playlist_id, track)
        os.startfile(f"spotify:playlist:{playlist_id}:highlight:{track['uri']}")
        if not self.available:
            return
        start = time.time()
        while time.time() - start < WAIT_FOR_BUTTON:
            button = self._song_button(track)
            if button:
                self._press(button)
                print(f"  started song: {track.get('title')}")
                return
            if self._is_playing(track):
                print(f"  that song is already playing: {track.get('title')}")
                return
            time.sleep(0.4)
        print(f"  (couldn't find the Play button for {track.get('title')!r} in Spotify)")

    def _do_like(self):
        if not self.available:
            return "failed"
        # The bottom bar's "Add to playlist" is the lowest one on screen.
        buttons = [(b.CurrentBoundingRectangle.top, b) for n, b in self._buttons() if n.lower() == "add to playlist"]
        if not buttons:
            print("  (couldn't find Spotify's 'Add to playlist' button)")
            return "failed"
        buttons.sort(key=lambda t: t[0])
        self._press(buttons[-1][1])
        time.sleep(0.8)
        # Already liked? Then Spotify opens a menu instead - close it again.
        names = {n.lower(): b for n, b in self._buttons()}
        for word in ("cancel", "done", "close"):
            if word in names:
                self._press(names[word])
                print("  that song was already in Liked Songs")
                return "already"
        print("  added the song to Liked Songs")
        return "added"

    # ---------- reading a whole playlist ----------

    def _do_read(self, playlist_id, names):
        main = self._main_window()
        if not main:
            return None
        restore = _user32.IsIconic(main)
        if restore:                                   # Spotify only draws the list when it's on screen
            _user32.ShowWindow(main, 4)               # SW_SHOWNOACTIVATE: show it without stealing focus
        try:
            os.startfile("spotify:playlist:" + playlist_id)
            grid = self._wait_for_tracklist(names)
            if grid is None:
                print("  (Spotify didn't show the playlist's song list)")
                return None
            total = self._row_count(grid)
            scroller = self._scroller_of(grid)
            if scroller is None:
                print("  (couldn't scroll Spotify's song list)")
                return None
            started = time.time()
            print(f"  reading playlist from Spotify ({total or '?'} songs)...")
            songs, seen = [], {}
            scroller.SetScrollPercent(-1, 0)
            time.sleep(0.6)
            stuck = 0
            while time.time() - started < READ_TIME_LIMIT:
                before = len(songs)
                self._merge(songs, seen, self._visible_rows(grid), max(0.0, scroller.CurrentVerticalScrollPercent))
                if total and len(songs) >= total:
                    break
                pos, view = scroller.CurrentVerticalScrollPercent, scroller.CurrentVerticalViewSize
                if pos >= 99.9 or pos < 0:
                    stuck = stuck + 1 if len(songs) == before else 0
                    if stuck >= 3:
                        break
                scroller.SetScrollPercent(-1, min(100.0, max(0.0, pos) + max(1.0, view * 0.6)))
                time.sleep(0.35)
                grid = self._wait_for_tracklist(names, timeout=2.0) or grid   # the list gets rebuilt sometimes
            scroller.SetScrollPercent(-1, 0)
            print(f"  read {len(songs)} songs from Spotify in {time.time() - started:.0f} s")
            if songs and not any(s.get("uri") for s in songs):
                self._write_debug(grid)
            return songs
        finally:
            if restore:
                _user32.ShowWindow(main, 7)           # SW_SHOWMINNOACTIVE: back to minimised

    def _do_song_by_scrolling(self, playlist_id, track):
        """For songs we don't know the Spotify ID of: open the playlist, jump straight to where the
        song was during the startup scan and press its Play button. Only if it has moved (playlist
        changed, window resized a lot) does it fall back to looking through the list."""
        os.startfile("spotify:playlist:" + playlist_id)
        if not self.available:
            return
        grid = self._wait_for_tracklist([], timeout=WAIT_FOR_BUTTON)
        scroller = self._scroller_of(grid) if grid else None
        if scroller and "at" in track:
            time.sleep(0.3)
            view = max(1.0, scroller.CurrentVerticalViewSize)
            for nudge in (0, -0.5, 0.5, -1.0, 1.0):
                scroller.SetScrollPercent(-1, min(100.0, max(0.0, track["at"] + nudge * view)))
                deadline = time.time() + (1.2 if nudge == 0 else 0.6)
                while time.time() < deadline:
                    button = self._song_button(track)
                    if button:
                        self._press(button)
                        print(f"  started song: {track.get('title')}")
                        return
                    time.sleep(0.15)
            print("  (the song wasn't where it was at startup - looking through the playlist)")
        started = time.time()
        if scroller:
            scroller.SetScrollPercent(-1, 0)
            time.sleep(0.5)
        while time.time() - started < 40:
            button = self._song_button(track)
            if button:
                self._press(button)
                print(f"  started song: {track.get('title')}")
                return
            if not scroller:
                break
            pos, view = scroller.CurrentVerticalScrollPercent, scroller.CurrentVerticalViewSize
            if pos >= 99.9:
                break
            scroller.SetScrollPercent(-1, min(100.0, max(0.0, pos) + max(1.0, view * 0.6)))
            time.sleep(0.35)
        print(f"  (couldn't find {track.get('title')!r} in the playlist in Spotify)")

    def _write_debug(self, grid):
        """Spotify didn't show song links: save what one row looks like, to fix it later."""
        U = self.U
        try:
            cache = self.uia.CreateCacheRequest()
            for prop in (U.UIA_NamePropertyId, U.UIA_ControlTypePropertyId, U.UIA_ValueValuePropertyId,
                         U.UIA_LegacyIAccessibleValuePropertyId, U.UIA_HelpTextPropertyId, U.UIA_AriaPropertiesPropertyId):
                cache.AddProperty(prop)
            rows = grid.FindAllBuildCache(U.TreeScope_Descendants,
                self.uia.CreatePropertyCondition(U.UIA_ControlTypePropertyId, U.UIA_DataItemControlTypeId), cache)
            lines = []
            for r in range(min(3, rows.Length)):
                row = rows.GetElement(r)
                parts = row.FindAllBuildCache(U.TreeScope_Descendants, self.uia.CreateTrueCondition(), cache)
                lines.append(f"--- row {r}")
                for i in range(min(40, parts.Length)):
                    e = parts.GetElement(i)
                    vals = []
                    for prop in (U.UIA_ValueValuePropertyId, U.UIA_LegacyIAccessibleValuePropertyId,
                                 U.UIA_HelpTextPropertyId, U.UIA_AriaPropertiesPropertyId):
                        try:
                            vals.append(repr(e.GetCachedPropertyValue(prop))[:80])
                        except Exception:
                            vals.append("-")
                    lines.append(f"{e.CachedControlType} {e.CachedName!r:.60} " + " | ".join(vals))
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "spotify_rows_debug.txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            print(f"  (Spotify didn't share the songs' links - saved {path} so it can be fixed)")
        except Exception as e:
            print(f"  (couldn't save the debug file: {e})")

    def _main_window(self):
        best, best_area = None, 0
        for hwnd in spotify_windows():
            r = wt.RECT()
            _user32.GetWindowRect(hwnd, ctypes.byref(r))
            area = (r.right - r.left) * (r.bottom - r.top)
            if _user32.IsIconic(hwnd):
                area = 1                                  # minimised windows report a tiny size
            if area >= best_area:
                best, best_area = hwnd, area
        return best

    def _wait_for_tracklist(self, names, timeout=10.0):
        """Spotify's song list is a 'grid' named after the playlist. Wait for it to appear."""
        U = self.U
        wanted = {n.lower() for n in names if n}
        cond = self.uia.CreateOrCondition(
            self.uia.CreatePropertyCondition(U.UIA_ControlTypePropertyId, U.UIA_DataGridControlTypeId),
            self.uia.CreatePropertyCondition(U.UIA_ControlTypePropertyId, U.UIA_TableControlTypeId))
        start = time.time()
        while True:
            grids = []
            for hwnd in spotify_windows():
                try:
                    found = self.uia.ElementFromHandle(hwnd).FindAll(U.TreeScope_Descendants, cond)
                except Exception:
                    continue
                for i in range(found.Length):
                    grids.append(found.GetElement(i))
            for g in grids:                               # the one named after the playlist
                if (g.CurrentName or "").strip().lower() in wanted:
                    return g
            if grids and (not wanted or time.time() - start > 4.0):
                return max(grids, key=self._row_count)    # name didn't match - take the biggest list
            if time.time() - start > timeout:
                return None
            time.sleep(0.4)

    def _row_count(self, grid):
        try:
            p = grid.GetCurrentPattern(self.U.UIA_GridPatternId)
            n = p.QueryInterface(self.U.IUIAutomationGridPattern).CurrentRowCount
            return max(0, n - 1)                          # minus the header row
        except Exception:
            return 0

    def _scroller_of(self, element):
        """The nearest container above the song list that can scroll up and down."""
        U = self.U
        walker = self.uia.ControlViewWalker
        node = element
        for _ in range(25):
            try:
                pattern = node.GetCurrentPattern(U.UIA_ScrollPatternId)
                if pattern:
                    sp = pattern.QueryInterface(U.IUIAutomationScrollPattern)
                    if sp.CurrentVerticallyScrollable:
                        return sp
                node = walker.GetParentElement(node)
            except Exception:
                return None
            if not node:
                return None
        return None

    def _visible_rows(self, grid):
        """The songs Spotify has drawn right now, top to bottom: (row number or None, title, artist, uri)."""
        U = self.U
        cache = self.uia.CreateCacheRequest()
        for prop in (U.UIA_NamePropertyId, U.UIA_BoundingRectanglePropertyId, U.UIA_ControlTypePropertyId,
                     U.UIA_ValueValuePropertyId, U.UIA_AriaPropertiesPropertyId,
                     U.UIA_LegacyIAccessibleValuePropertyId, U.UIA_HelpTextPropertyId):
            cache.AddProperty(prop)
        rows_found = grid.FindAllBuildCache(
            U.TreeScope_Descendants,
            self.uia.CreatePropertyCondition(U.UIA_ControlTypePropertyId, U.UIA_DataItemControlTypeId), cache)
        parts = grid.FindAllBuildCache(
            U.TreeScope_Descendants,
            self.uia.CreateOrCondition(
                self.uia.CreatePropertyCondition(U.UIA_ControlTypePropertyId, U.UIA_HyperlinkControlTypeId),
                self.uia.CreatePropertyCondition(U.UIA_ControlTypePropertyId, U.UIA_ButtonControlTypeId)), cache)

        rows = []
        for i in range(rows_found.Length):
            r = rows_found.GetElement(i)
            rect = r.CachedBoundingRectangle
            if rect.bottom - rect.top < 10:
                continue
            try:
                aria = r.CachedAriaProperties or ""
            except Exception:
                aria = ""
            m = re.search(r"rowindex=(\d+)", aria)
            rows.append({"top": rect.top, "bottom": rect.bottom, "index": int(m.group(1)) if m else None,
                         "links": [], "buttons": []})
        rows.sort(key=lambda r: r["top"])
        for i in range(parts.Length):
            e = parts.GetElement(i)
            rect = e.CachedBoundingRectangle
            mid = (rect.top + rect.bottom) / 2
            for row in rows:
                if row["top"] <= mid <= row["bottom"]:
                    name = (e.CachedName or "").strip()
                    if e.CachedControlType == U.UIA_HyperlinkControlTypeId:
                        row["links"].append((rect.left, rect.top, name, self._cached_value(e)))
                    else:
                        row["buttons"].append(name)
                    break

        out = []
        for row in rows:
            uri, title = None, None
            for _, _, name, value in sorted(row["links"]):
                m = TRACK_ID.search(value)
                if m:
                    uri, title = "spotify:track:" + m.group(1), name
                    break
            artist = ""
            for b in row["buttons"]:                      # "Play <title> by <artist>"
                low = b.lower()
                if low.startswith(("play ", "pause ")) and " by " in low:
                    rest = b.split(" ", 1)[1]
                    if title and rest.lower().startswith(title.lower() + " by "):
                        artist = rest[len(title) + 4:]
                    else:
                        title_guess, artist = rest.rsplit(" by ", 1)
                        title = title or title_guess
                    break
            if not artist:                                # no Play button: use the artist links
                artists = [n for _, _, n, v in sorted(row["links"], key=lambda t: (t[1], t[0])) if "/artist/" in v]
                artist = ", ".join(artists)
            if title:
                out.append((row["index"], title.strip(), artist.strip(), uri))
        return out

    def _cached_value(self, element):
        """A link's web address, wherever this version of Spotify puts it."""
        U = self.U
        found = []
        for prop in (U.UIA_ValueValuePropertyId, U.UIA_LegacyIAccessibleValuePropertyId, U.UIA_HelpTextPropertyId):
            try:
                v = element.GetCachedPropertyValue(prop)
                if isinstance(v, str) and v:
                    found.append(v)
            except Exception:
                pass
        return " ".join(found)

    @staticmethod
    def _merge(songs, seen, visible, at=0.0):
        """Add newly drawn rows to the list, keeping the playlist's order.
        "at" = how far down the list was scrolled (%) when the song was on screen - used to jump
        straight back to it later."""
        for index, title, artist, uri in visible:
            key = index if index is not None else (uri or (title.lower(), artist.lower()))
            if key in seen:
                continue
            seen[key] = True
            song = {"title": title, "subtitle": artist, "uri": uri, "at": round(at, 2)}
            if index is not None:
                song["_row"] = index
            songs.append(song)
        if songs and all("_row" in s for s in songs):
            songs.sort(key=lambda s: s["_row"])

    # ---------- finding and pressing buttons ----------

    def _song_button(self, track):
        prefix = f"play {track.get('title', '')} by ".lower()
        artist = (track.get("subtitle") or "").lower()
        fallback = None
        for name, button in self._play_buttons():
            low = name.lower()
            if low.startswith(prefix):
                if artist and artist.split(",")[0].strip() in low:
                    return button
                fallback = fallback or button
        return fallback

    def _is_playing(self, track):
        prefix = f"pause {track.get('title', '')} by ".lower()
        return any(n.lower().startswith(prefix) for n, _ in self._buttons())

    def _play_buttons(self):
        return [(n, b) for n, b in self._buttons() if n.lower().startswith("play")]

    def _buttons(self):
        """Every button in Spotify's window(s), with names fetched in one go (fast)."""
        U = self.U
        cache = self.uia.CreateCacheRequest()
        cache.AddProperty(U.UIA_NamePropertyId)
        cond = self.uia.CreatePropertyCondition(U.UIA_ControlTypePropertyId, U.UIA_ButtonControlTypeId)
        result = []
        for hwnd in spotify_windows():
            try:
                window = self.uia.ElementFromHandle(hwnd)
                found = window.FindAllBuildCache(U.TreeScope_Descendants, cond, cache)
            except Exception:
                continue
            for i in range(found.Length):
                b = found.GetElement(i)
                result.append(((b.CachedName or "").strip(), b))
        return result

    def _press(self, button):
        U = self.U
        pattern = button.GetCurrentPattern(U.UIA_InvokePatternId)
        pattern.QueryInterface(U.IUIAutomationInvokePattern).Invoke()


# ---------- finding Spotify's windows quickly ----------

_user32 = ctypes.windll.user32 if os.name == "nt" else None
_kernel32 = ctypes.windll.kernel32 if os.name == "nt" else None


def _process_name(pid):
    handle = _kernel32.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
    if not handle:
        return ""
    try:
        buf = ctypes.create_unicode_buffer(260)
        size = wt.DWORD(260)
        if _kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            return os.path.basename(buf.value)
        return ""
    finally:
        _kernel32.CloseHandle(handle)


def spotify_windows():
    found = []
    names = {}

    @ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
    def callback(hwnd, _):
        if _user32.IsWindowVisible(hwnd) and _user32.GetWindowTextLengthW(hwnd) > 0:
            pid = wt.DWORD()
            _user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value not in names:
                names[pid.value] = _process_name(pid.value).lower()
            if names[pid.value] == "spotify.exe":
                found.append(hwnd)
        return True

    _user32.EnumWindows(callback, 0)
    return found
