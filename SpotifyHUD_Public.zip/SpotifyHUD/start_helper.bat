@echo off
rem Starts the helper quietly in the background (look for the green icon by the clock).
start "" pythonw "%~dp0spotify_helper.py"
