// Screen + touch setup for the Freenove FNK0104N (3.5", ST77922), in LANDSCAPE.
// Based on Freenove's Sketch_16.1 display code. The panel itself stays in portrait
// (320 wide x 480 tall); we turn each block of pixels sideways before sending it.
#include "display.h"
#include <SPI.h>
#include "ST77922.h"
#include "ST77922_Touch.h"

#ifndef FNK0104N_3P5_320x480_ST77922
  #error "This display code is only for the FNK0104N (3.5 inch). Use the FNK0104N libraries."
#endif

static const uint16_t PANEL_W = 320;   // physical panel size (portrait)
static const uint16_t PANEL_H = 480;
static const uint32_t BUF_PIXELS = SCREEN_W * 20;

static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf1[BUF_PIXELS];      // LVGL draws into one of these...
static lv_color_t buf2[BUF_PIXELS];      // ...while the other one is being sent to the screen
static uint16_t rotated[BUF_PIXELS];     // a finished block, turned sideways

// The other CPU core turns finished blocks sideways and sends them to the screen,
// so drawing the next block and sending this one happen at the same time (smoother).
struct FlushJob { lv_disp_drv_t *disp; lv_area_t area; lv_color_t *pixels; };
static QueueHandle_t flushQueue;

ST77922 tft_st77922 = ST77922();
ST77922_TOUCH touch_st77922;

// ---------- Backlight / sleep ----------
static const int BACKLIGHT_PIN = LCD_BL;   // pin 41 on the FNK0104N, HIGH = on
static uint8_t awakeLevel = 255;           // brightness when awake
static int targetLevel = 255, currentLevel = 255;
static volatile bool asleep = false;
static volatile bool wakeRequested = false;
static bool ignoreUntilRelease = false;     // the tap that wakes the screen doesn't press anything
static unsigned long lastTouch = 0;

// The ST77922 needs updates aligned to blocks of 4 pixels.
static void my_rounder_cb(lv_disp_drv_t *disp_drv, lv_area_t *area)
{
  area->x1 = area->x1 & ~0x3;
  area->y1 = area->y1 & ~0x3;
  area->x2 = area->x2 | 0x3;
  area->y2 = area->y2 | 0x3;
}

static void sendBlock(const lv_area_t *area, const lv_color_t *color_p)
{
  const uint32_t w = area->x2 - area->x1 + 1;   // landscape block size
  const uint32_t h = area->y2 - area->y1 + 1;
  const uint16_t *src = (const uint16_t *)color_p;

#if FLIP_SCREEN == 0
  // landscape (x, y)  ->  panel (PANEL_W-1-y, x): each landscape row becomes a panel column
  for (uint32_t r = 0; r < h; r++) {
    const uint16_t *in = src + r * w;
    uint16_t *out = rotated + (h - 1 - r);
    for (uint32_t c = 0; c < w; c++, out += h) *out = in[c];
  }
  tft_st77922.Fill_Colors(PANEL_W - area->y1 - h, area->x1, h, w, rotated);
#else
  // landscape (x, y)  ->  panel (y, PANEL_H-1-x)
  for (uint32_t r = 0; r < h; r++) {
    const uint16_t *in = src + r * w;
    uint16_t *out = rotated + (w - 1) * h + r;
    for (uint32_t c = 0; c < w; c++, out -= h) *out = in[c];
  }
  tft_st77922.Fill_Colors(area->y1, PANEL_H - area->x1 - w, h, w, rotated);
#endif
}

static void flushTask(void *)
{
  FlushJob job;
  while (true) {
    if (xQueueReceive(flushQueue, &job, portMAX_DELAY) == pdTRUE) {
      sendBlock(&job.area, job.pixels);
      lv_disp_flush_ready(job.disp);   // tell LVGL this buffer is free again
    }
  }
}

static void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p)
{
  FlushJob job = {disp, *area, color_p};
  xQueueSend(flushQueue, &job, portMAX_DELAY);   // hand it to the other core and carry on
}

static void my_touchpad_read(lv_indev_drv_t *indev_driver, lv_indev_data_t *data)
{
  if (touch_st77922.Get_Touch()) {
    lastTouch = millis();
    if (asleep || ignoreUntilRelease) {   // screen was dark: just wake it up
      if (asleep) wakeRequested = true;
      ignoreUntilRelease = true;
      data->state = LV_INDEV_STATE_REL;
      return;
    }
    uint16_t px = touch_st77922.touch.x[0];   // panel coordinates (portrait)
    uint16_t py = touch_st77922.touch.y[0];
    if (px < PANEL_W && py < PANEL_H) {
#if FLIP_SCREEN == 0
      data->point.x = py;
      data->point.y = PANEL_W - 1 - px;
#else
      data->point.x = PANEL_H - 1 - py;
      data->point.y = px;
#endif
      data->state = LV_INDEV_STATE_PR;
    }
  } else {
    ignoreUntilRelease = false;
    data->state = LV_INDEV_STATE_REL;
  }
}

void Display::init(void)
{
  tft_st77922.Init();
  tft_st77922.Set_Rotation(0);     // panel stays portrait; we rotate ourselves
  touch_st77922.init();
  touch_st77922.Set_Rotation(0);

  analogWriteFrequency(BACKLIGHT_PIN, 20000);   // fast enough not to flicker or whine
  analogWrite(BACKLIGHT_PIN, currentLevel);
  lastTouch = millis();

  lv_init();
  flushQueue = xQueueCreate(2, sizeof(FlushJob));
  xTaskCreatePinnedToCore(flushTask, "flush", 4096, NULL, 3, NULL, 0);   // core 0; loop() runs on core 1
  lv_disp_draw_buf_init(&draw_buf, buf1, buf2, BUF_PIXELS);

  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = SCREEN_W;
  disp_drv.ver_res = SCREEN_H;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.rounder_cb = my_rounder_cb;
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register(&disp_drv);

  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);
}

void Display::routine(void)
{
  if (wakeRequested) {
    wakeRequested = false;
    wake();
  }
  // Fade the backlight a little each time, towards where it should be.
  if (currentLevel != targetLevel) {
    static unsigned long lastStep = 0;
    if (millis() - lastStep >= 10) {
      lastStep = millis();
      int step = (targetLevel > currentLevel) ? 12 : -6;   // wake quickly, fade out gently
      currentLevel = constrain(currentLevel + step, min(currentLevel, targetLevel), max(currentLevel, targetLevel));
      analogWrite(BACKLIGHT_PIN, currentLevel);
    }
  }
  lv_task_handler();
}

void Display::sleep(void) { asleep = true; targetLevel = 0; }
void Display::wake(void) { asleep = false; targetLevel = awakeLevel; lastTouch = millis(); }
bool Display::sleeping(void) { return asleep; }
unsigned long Display::lastTouchMs(void) { return lastTouch; }

void Display::setBrightness(uint8_t level)
{
  awakeLevel = level;
  if (!asleep) targetLevel = level;
}
