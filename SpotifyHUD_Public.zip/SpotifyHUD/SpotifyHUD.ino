/*
 * Spotify HUD - shows what's playing on your PC (album art + song name), lets you control it,
 * and has a second page with your playlists (swipe left/right to switch pages).
 * Board: Freenove ESP32-S3 Display FNK0104N (3.5", ST77922), landscape.
 *
 * Works together with spotify_helper.py running on your Windows PC, over the USB cable.
 * The PC draws the song name as a picture (so Japanese and other languages work).
 *
 *   PC -> board:  "NP<tab>1<tab>Song title<tab>Artist"  (1 = playing, 0 = paused)
 *                 "NONE"                                 (nothing playing)
 *                 "IMG<tab>ART" + picture bytes          (album art, sent in 4 KB pieces)
 *                 "IMG<tab>TXT" + picture bytes          (song name + artist, drawn by the PC)
 *                 "NOART"                                (this song has no album art)
 *                 "PLCLEAR"                              (playlist list is about to be re-sent)
 *                 "PL<tab>2<tab>Playlist name"           (playlist number 2)
 *                 "IMG<tab>PL2" + picture bytes          (cover of playlist number 2)
 *                 "SLWAIT"                               (song list still loading)
 *                 "SL<tab>pl<tab>page<tab>pages<tab>rows" + "IMG<tab>SR0".."SR5"  (a page of songs)
 *                 "IMG<tab>SI0".."SI5" + picture bytes   (little album cover for each song row)
 *                 "TL<tab>83000<tab>215000"     (song position and length, in milliseconds)
 *                 "VOL<tab>40<tab>100"          (PC volume, Spotify volume; 0-100, -1 = unknown)
 *                 "BG<tab>3A1F5C"               (background colour picked from the album art)
 *                 "IMG<tab>CLK" + picture bytes (the clock: time + date, drawn by the PC each minute)
 *                 "IMG<tab>CLB" + picture bytes (clock screen's bottom strip: last played + weather)
 *                 "STATS<tab>CPU 12%  ...      (PC info shown under the clock)
 *                 "MODES<tab>1<tab>0"           (shuffle 1/0, repeat 0 off/1 all/2 one; -1 = not available)
 *                 "LIKED<tab>added"             (result of LIKE: added / already / failed)
 *   board -> PC:  "PLAYPAUSE", "NEXT", "PREV", "HELLO", "ACK",
 *                 "SEARCH<tab>yoasobi"          (search all playlists; results come back as list -2)
 *                 "RESULTS<tab>1"               (page 1 of the search results)
 *                 "PLAYRESULT<tab>4"            (play search result 4)
 *                 "FIND<tab>2<tab>yoasobi"      (search inside playlist 2 only; results come back as list -2)
 *                 "SEEK<tab>60000"              (jump to 1:00 in the song)
 *                 "SHUFFLE", "REPEAT", "LIKE"
 *                 "SETVOL<tab>pc<tab>55"        (set PC volume - or "spotify")
 *                 "INFO<tab>..."                (memory report, shown in the helper's log)
 *                 "OPEN<tab>2"                  (play all of playlist 2)
 *                 "SONGS<tab>2<tab>0"           (send page 0 of playlist 2's songs)
 *                 "PLAYSONG<tab>2<tab>13"       (play song 13 of playlist 2)
 *
 * Nothing to configure - just upload it. Your playlists are set in playlists.txt on the PC.
 * Screen upside down? Set FLIP_SCREEN to 1 in display.h.
 * Button sounds play through a speaker plugged into the board's speaker connector.
 */

#include "display.h"   // screen + touch code (landscape)
#include "sounds.h"    // button beeps
#include <Preferences.h> // remembers your volume choice (PC / Spotify)
#include "pc_link.h"     // talks to the PC over USB or WiFi
#if __has_include("wifi_config.h")
#include "wifi_config.h" // your WiFi name and password (yours - updates never replace it)
#else
#define WIFI_NAME ""     // no wifi_config.h yet: USB only (see wifi_config.example.h)
#define WIFI_PASSWORD ""
#endif

// ---------- Sound settings ----------
#define BUTTON_SOUNDS 1     // 1 = beep when you tap a button, 0 = silent
#define SOUND_VOLUME  70    // 0 (silent) to 100 (loud)

// ---------- Screen settings ----------
#define CLOCK_AFTER_SECONDS  20   // show the clock after this long with nothing playing (0 = never)
#define SCREEN_SLEEP_SECONDS 600  // turn the screen off after this long with nothing playing (0 = never)
#define SCREEN_BRIGHTNESS    255  // 1 (dim) to 255 (full)

Display screen;

// ---------- Pictures from the PC (sizes must match spotify_helper.py) ----------
#define ART_W 130
#define ART_H 130
#define TXT_W 440
#define TXT_H 64
#define COVER_SIZE 80        // playlist covers
#define MAX_PLAYLISTS 6      // how many playlists fit in memory
#define ROW_W 440            // one song in the song list (a greyscale picture drawn by the PC)
#define ROW_H 34
#define SONGS_PER_PAGE 6
#define SONG_ICON 30         // little album cover in each song row
#define ICON_X 36            // ...and where it sits in the row
#define SEARCH_LIST -2       // "playlist number" used for search results
#define CLK_W 440            // the clock picture (time + date)
#define CLK_H 170
#define STRIP_W 448          // the clock screen's bottom strip (last played + weather)
#define STRIP_H 96
#define STRIP_Y 184
#define CHUNK 16384          // the PC waits for "ACK" after each 16 KB piece

struct Picture {
  uint16_t w, h;
  bool grey;          // true = 4-bit greyscale (song rows), false = full colour
  uint8_t *pixels;
  lv_img_dsc_t dsc;
  lv_obj_t *img;
};
Picture art = {ART_W, ART_H, false};
Picture txt = {TXT_W, TXT_H, true};   // greyscale, tinted white (saves memory)
Picture covers[MAX_PLAYLISTS];
Picture rows[SONGS_PER_PAGE];
Picture icons[SONGS_PER_PAGE];
Picture clockPic = {CLK_W, CLK_H, true};
Picture clockStrip = {STRIP_W, STRIP_H, true};

// ---------- Clock screen ----------
lv_obj_t *clockView, *lblStats, *clockArt, *btnResume;
bool clockShown = false, clockReady = false;
unsigned long clockDismissedAt = 0;

Picture *receiving = nullptr;   // which picture is arriving right now (or none)
uint32_t received = 0;
unsigned long lastByteAt = 0;

// ---------- State ----------
String rxLine;                     // text received so far from the PC
unsigned long lastMessageAt = 0;   // when we last heard from the PC helper
unsigned long lastHelloAt = 0;
unsigned long lastPlayingAt = 0;   // when music was last playing (for screen sleep)

// Song position (the board counts up by itself between updates from the PC)
uint32_t songPosMs = 0, songLenMs = 0;
unsigned long songPosAt = 0;
bool draggingProgress = false;

// Volume
Preferences prefs;
int volPC = -1, volSpotify = -1;
bool volumeIsSpotify = false;        // false = slider controls the PC, true = just Spotify
unsigned long volTouchedAt = 0;      // ignore updates from the PC while you're dragging
unsigned long volSentAt = 0;

// Background colour (fades between album colours)
lv_color_t bgFrom, bgTo, bgNow;
bool helperConnected = false;
bool isPlaying = false;
String shownTitle = "-", shownArtist = "-";
int playlistCount = 0;
int songPlaylist = -1;      // which playlist's songs are showing (-1 = none)
int songPage = 0, songPages = 1;
int searchScope = -1;       // -1 = search all playlists, otherwise search inside this playlist

// ---------- Screen objects ----------
lv_obj_t *pages, *playerPage, *playlistPage, *playlistGrid, *lblNoPlaylists;
lv_obj_t *gridView, *songView, *lblSongsTitle, *lblSongsInfo, *lblPageNum, *rowBtns[SONGS_PER_PAGE];
lv_obj_t *btnPlayAll, *searchView, *searchBox, *keyboard, *lblSearchHint;
String playlistNames[MAX_PLAYLISTS];
lv_obj_t *lblStatus, *lblTitle, *lblArtist, *lblPlayIcon, *artPlaceholder;
lv_obj_t *progress, *lblElapsed, *lblLength, *volSlider, *lblVolIcon, *btnVolTarget, *lblVolTarget;
lv_obj_t *btnShuffle, *btnRepeat, *lblRepeat, *btnLike, *lblLike;
int shuffleMode = -1, repeatMode = -1;   // -1 = not available

// Functions used before they're written out further down
void showSongList(int playlist);
void showGrid();
void showSearch();
void showSearchIn(int playlist);
void leaveSongList();
void hideSongRows();
void hideClock();
void updateClockLastPlayed();
void setPlayIcon(bool playing);
void requestSongPage(int page);
static void onSongTapped(lv_event_t *e);

// ============================================================
//  Pictures
// ============================================================

uint32_t pictureBytes(Picture &p) {
  return p.grey ? (uint32_t)((p.w + 1) / 2) * p.h : (uint32_t)p.w * p.h * 2;
}

// Use the board's extra memory (PSRAM) if it has it, otherwise normal memory.
uint8_t *allocPixels(uint32_t bytes) {
  uint8_t *p = (uint8_t *)heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM);
  return p ? p : (uint8_t *)malloc(bytes);
}

void setupPicture(Picture &p, lv_obj_t *parent, int x, int y) {
  if (!p.pixels) p.pixels = allocPixels(pictureBytes(p));
  memset(&p.dsc, 0, sizeof(p.dsc));
  p.dsc.header.cf = p.grey ? LV_IMG_CF_ALPHA_4BIT : LV_IMG_CF_TRUE_COLOR;
  p.dsc.header.w = p.w;
  p.dsc.header.h = p.h;
  p.dsc.data_size = pictureBytes(p);
  p.dsc.data = p.pixels;
  p.img = lv_img_create(parent);
  lv_obj_set_pos(p.img, x, y);
  lv_obj_add_flag(p.img, LV_OBJ_FLAG_HIDDEN);
  if (p.grey) {   // greyscale pictures are tinted white
    lv_obj_set_style_img_recolor(p.img, lv_color_hex(0xFFFFFF), 0);
    lv_obj_set_style_img_recolor_opa(p.img, LV_OPA_COVER, 0);
  }
}

void showPicture(Picture &p, bool show) {
  if (!p.img) return;
  if (show) {
    lv_img_cache_invalidate_src(&p.dsc);   // the picture changed - forget the old one
    lv_img_set_src(p.img, &p.dsc);
    lv_obj_clear_flag(p.img, LV_OBJ_FLAG_HIDDEN);
    lv_obj_invalidate(p.img);
  } else {
    lv_obj_add_flag(p.img, LV_OBJ_FLAG_HIDDEN);
  }
  if (&p == &clockPic && show) clockReady = true;
  if (&p == &art && clockShown) updateClockLastPlayed();
  // A song row's button only shows once its picture has arrived.
  for (int k = 0; k < SONGS_PER_PAGE; k++)
    if (&p == &rows[k]) {
      if (show) lv_obj_clear_flag(rowBtns[k], LV_OBJ_FLAG_HIDDEN);
      else lv_obj_add_flag(rowBtns[k], LV_OBJ_FLAG_HIDDEN);
    }
  // The song-name picture replaces the plain text labels.
  if (&p == &txt) {
    if (show) { lv_obj_add_flag(lblTitle, LV_OBJ_FLAG_HIDDEN); lv_obj_add_flag(lblArtist, LV_OBJ_FLAG_HIDDEN); }
    else      { lv_obj_clear_flag(lblTitle, LV_OBJ_FLAG_HIDDEN); lv_obj_clear_flag(lblArtist, LV_OBJ_FLAG_HIDDEN); }
  }
}

// ============================================================
//  Small helpers
// ============================================================

void setText(lv_obj_t *label, String &shown, const String &text) {
  if (shown == text) return;   // don't redraw if nothing changed
  shown = text;
  lv_label_set_text(label, text.c_str());
}

void setPlayIcon(bool playing) {
  lv_label_set_text(lblPlayIcon, playing ? LV_SYMBOL_PAUSE : LV_SYMBOL_PLAY);
}

void beep(Sound s) {
#if BUTTON_SOUNDS
  playSound(s);
#endif
}

void goToPage(int page) {
  lv_obj_set_tile_id(pages, page, 0, LV_ANIM_ON);
}

lv_obj_t *makeLabel(lv_obj_t *parent, int x, int y, int w, int h, uint32_t color, const lv_font_t *font) {
  lv_obj_t *l = lv_label_create(parent);
  lv_obj_set_pos(l, x, y);
  lv_obj_set_size(l, w, h);
  lv_label_set_long_mode(l, LV_LABEL_LONG_DOT);   // "..." if it's too long
  lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_set_style_text_color(l, lv_color_hex(color), 0);
  if (font) lv_obj_set_style_text_font(l, font, 0);
  lv_label_set_text(l, "");
  return l;
}

// A small grey text link in the top corner, e.g. "Playlists >"
void makeCornerLink(lv_obj_t *parent, const char *text, lv_align_t align, int page) {
  lv_obj_t *btn = lv_btn_create(parent);
  lv_obj_set_size(btn, 120, 34);
  lv_obj_align(btn, align, align == LV_ALIGN_TOP_RIGHT ? -4 : 4, 2);
  lv_obj_set_style_bg_opa(btn, LV_OPA_TRANSP, 0);
  lv_obj_set_style_shadow_width(btn, 0, 0);
  lv_obj_add_event_cb(btn, [](lv_event_t *e) { goToPage((int)(intptr_t)lv_event_get_user_data(e)); },
                      LV_EVENT_CLICKED, (void *)(intptr_t)page);
  lv_obj_t *l = lv_label_create(btn);
  lv_obj_set_style_text_color(l, lv_color_hex(0x888888), 0);
  lv_label_set_text(l, text);
  lv_obj_center(l);
}

// ============================================================
//  Page 1: the player
// ============================================================

// Called when play/pause, next or previous is tapped.
// The command ("PLAYPAUSE", "NEXT", "PREV") is attached to each button.
static void onPlayerButton(lv_event_t *e) {
  const char *command = (const char *)lv_event_get_user_data(e);
  pc.println(command);   // send it to the PC helper

  if (strcmp(command, "NEXT") == 0) beep(SOUND_NEXT);
  else if (strcmp(command, "PREV") == 0) beep(SOUND_PREV);
  else {
    isPlaying = !isPlaying;   // flip the icon straight away so it feels snappy
    setPlayIcon(isPlaying);
    beep(isPlaying ? SOUND_PLAY : SOUND_PAUSE);
  }
}

lv_obj_t *makeRoundButton(lv_obj_t *parent, int size, uint32_t color, const char *symbol,
                          const char *command, lv_obj_t **iconOut) {
  lv_obj_t *btn = lv_btn_create(parent);
  lv_obj_set_size(btn, size, size);
  lv_obj_set_style_radius(btn, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_color(btn, lv_color_hex(color), 0);
  lv_obj_add_event_cb(btn, onPlayerButton, LV_EVENT_CLICKED, (void *)command);

  lv_obj_t *icon = lv_label_create(btn);
  lv_obj_set_style_text_font(icon, &lv_font_montserrat_20, 0);
  lv_label_set_text(icon, symbol);
  lv_obj_center(icon);
  if (iconOut) *iconOut = icon;
  return btn;
}

// ---------- Progress bar ----------

uint32_t currentPosMs() {
  uint32_t pos = songPosMs + (isPlaying ? millis() - songPosAt : 0);
  return min(pos, songLenMs);
}

void formatTime(char *out, uint32_t ms) {
  uint32_t s = ms / 1000;
  sprintf(out, "%u:%02u", (unsigned)(s / 60), (unsigned)(s % 60));
}

void updateProgress() {
  bool show = songLenMs > 0 && helperConnected;
  for (lv_obj_t *o : {progress, lblElapsed, lblLength}) {
    if (show) lv_obj_clear_flag(o, LV_OBJ_FLAG_HIDDEN); else lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN);
  }
  if (!show) return;
  static char lastElapsed[12] = "", lastLength[12] = "";
  char t[12];
  uint32_t pos = currentPosMs();
  if (!draggingProgress) lv_slider_set_value(progress, songLenMs ? (int32_t)((uint64_t)pos * 1000 / songLenMs) : 0, LV_ANIM_OFF);
  else pos = (uint64_t)lv_slider_get_value(progress) * songLenMs / 1000;
  formatTime(t, pos);
  if (strcmp(t, lastElapsed)) { strcpy(lastElapsed, t); lv_label_set_text(lblElapsed, t); }
  formatTime(t, songLenMs);
  if (strcmp(t, lastLength)) { strcpy(lastLength, t); lv_label_set_text(lblLength, t); }
}

static void onProgressEvent(lv_event_t *e) {
  lv_event_code_t code = lv_event_get_code(e);
  if (code == LV_EVENT_PRESSED) draggingProgress = true;
  else if (code == LV_EVENT_VALUE_CHANGED && draggingProgress) updateProgress();
  else if (code == LV_EVENT_RELEASED || code == LV_EVENT_PRESS_LOST) {
    draggingProgress = false;
    uint32_t target = (uint64_t)lv_slider_get_value(progress) * songLenMs / 1000;
    pc.printf("SEEK\t%u\n", (unsigned)target);
    songPosMs = target;          // jump there straight away on the board too
    songPosAt = millis();
    beep(SOUND_NEXT);
  }
}

// ---------- Volume ----------

void showVolume() {
  int v = volumeIsSpotify ? volSpotify : volPC;
  lv_label_set_text(lblVolTarget, volumeIsSpotify ? "Spotify volume" : "PC volume");
  if (v < 0) {
    lv_obj_add_state(volSlider, LV_STATE_DISABLED);
    return;
  }
  lv_obj_clear_state(volSlider, LV_STATE_DISABLED);
  if (millis() - volTouchedAt > 1500) lv_slider_set_value(volSlider, v, LV_ANIM_OFF);
  lv_label_set_text(lblVolIcon, v == 0 ? LV_SYMBOL_MUTE : v < 50 ? LV_SYMBOL_VOLUME_MID : LV_SYMBOL_VOLUME_MAX);
}

static void onVolumeEvent(lv_event_t *e) {
  lv_event_code_t code = lv_event_get_code(e);
  if (code != LV_EVENT_VALUE_CHANGED && code != LV_EVENT_RELEASED) return;
  volTouchedAt = millis();
  int v = lv_slider_get_value(volSlider);
  if (volumeIsSpotify) volSpotify = v; else volPC = v;
  // While dragging, send at most ~8 updates a second; always send where you let go.
  if (code == LV_EVENT_RELEASED || millis() - volSentAt > 120) {
    volSentAt = millis();
    pc.printf("SETVOL\t%s\t%d\n", volumeIsSpotify ? "spotify" : "pc", v);
  }
  lv_label_set_text(lblVolIcon, v == 0 ? LV_SYMBOL_MUTE : v < 50 ? LV_SYMBOL_VOLUME_MID : LV_SYMBOL_VOLUME_MAX);
}

static void onVolumeTargetTapped(lv_event_t *e) {
  volumeIsSpotify = !volumeIsSpotify;
  prefs.putBool("volSpotify", volumeIsSpotify);
  volTouchedAt = 0;
  beep(SOUND_NEXT);
  showVolume();
}

// ---------- Background colour ----------

static void bgAnimStep(void *, int32_t v) {
  bgNow = lv_color_mix(bgTo, bgFrom, (uint8_t)v);
  lv_obj_set_style_bg_color(pages, bgNow, 0);
}

void setBackground(lv_color_t c) {
  if (lv_color_to32(c) == lv_color_to32(bgTo)) return;
  bgFrom = bgNow;
  bgTo = c;
  lv_anim_t a;
  lv_anim_init(&a);
  lv_anim_set_exec_cb(&a, bgAnimStep);
  lv_anim_set_values(&a, 0, 255);
  lv_anim_set_time(&a, 600);
  lv_anim_start(&a);
}

// ---------- Shuffle / repeat / like ----------

// Not available = invisible and untappable, but it keeps its space so the middle buttons stay put.
void setAvailable(lv_obj_t *btn, bool available) {
  lv_obj_set_style_opa(btn, available ? LV_OPA_COVER : LV_OPA_TRANSP, 0);
  if (available) lv_obj_add_flag(btn, LV_OBJ_FLAG_CLICKABLE);
  else lv_obj_clear_flag(btn, LV_OBJ_FLAG_CLICKABLE);
}

void showModes() {
  setAvailable(btnShuffle, shuffleMode >= 0);
  lv_obj_set_style_text_color(lv_obj_get_child(btnShuffle, 0),
                              lv_color_hex(shuffleMode == 1 ? 0x1DB954 : 0xDDDDDD), 0);   // green = on
  setAvailable(btnRepeat, repeatMode >= 0);
  lv_obj_set_style_text_color(lblRepeat, lv_color_hex(repeatMode > 0 ? 0x1DB954 : 0xDDDDDD), 0);
  lv_label_set_text(lblRepeat, repeatMode == 2 ? LV_SYMBOL_LOOP " 1" : LV_SYMBOL_LOOP);   // "1" = one song
}

lv_obj_t *makeIconButton(lv_obj_t *parent, const char *symbol, const char *command) {
  lv_obj_t *btn = lv_btn_create(parent);
  lv_obj_set_size(btn, 48, 48);
  lv_obj_set_style_radius(btn, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_opa(btn, LV_OPA_TRANSP, 0);
  lv_obj_set_style_bg_opa(btn, LV_OPA_20, LV_STATE_PRESSED);
  lv_obj_set_style_shadow_width(btn, 0, 0);
  lv_obj_add_event_cb(btn, [](lv_event_t *e) {
    const char *command = (const char *)lv_event_get_user_data(e);
    pc.println(command);
    beep(SOUND_NEXT);
  }, LV_EVENT_CLICKED, (void *)command);
  lv_obj_t *icon = lv_label_create(btn);
  lv_obj_set_style_text_font(icon, &lv_font_montserrat_20, 0);
  lv_label_set_text(icon, symbol);
  lv_obj_center(icon);
  return btn;
}

static void onLikeTapped(lv_event_t *e) {
  pc.println("LIKE");
  beep(SOUND_PLAY);
  lv_label_set_text(lblLike, "Saving...");
}

void showLikeResult(const String &result) {
  if (result == "added") lv_label_set_text(lblLike, LV_SYMBOL_OK "  Liked!");
  else if (result == "already") lv_label_set_text(lblLike, LV_SYMBOL_OK "  Already liked");
  else lv_label_set_text(lblLike, "Couldn't like it");
  // Put the normal text back after a few seconds
  lv_timer_t *t = lv_timer_create([](lv_timer_t *t) {
    lv_label_set_text(lblLike, LV_SYMBOL_PLUS "  Like song");
    lv_timer_del(t);
  }, 3000, NULL);
}

// ---------- Building the page ----------

void buildPlayerPage(lv_obj_t *page) {
  const int artX = (SCREEN_W - ART_W) / 2, artY = 8;    // album art: top middle
  const int txtX = (SCREEN_W - TXT_W) / 2, txtY = 142;  // song name: under the art
  lv_obj_set_style_bg_opa(page, LV_OPA_TRANSP, 0);      // let the album colour show through

  // Music-note placeholder, shown when there's no album art
  artPlaceholder = lv_obj_create(page);
  lv_obj_set_size(artPlaceholder, ART_W, ART_H);
  lv_obj_set_pos(artPlaceholder, artX, artY);
  lv_obj_set_style_bg_color(artPlaceholder, lv_color_hex(0x282828), 0);
  lv_obj_set_style_border_width(artPlaceholder, 0, 0);
  lv_obj_set_style_radius(artPlaceholder, 12, 0);
  lv_obj_clear_flag(artPlaceholder, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_t *note = lv_label_create(artPlaceholder);
  lv_obj_set_style_text_font(note, &lv_font_montserrat_20, 0);
  lv_obj_set_style_text_color(note, lv_color_hex(0x777777), 0);
  lv_label_set_text(note, LV_SYMBOL_AUDIO);
  lv_obj_center(note);

  setupPicture(art, page, artX, artY);   // drawn on top of the placeholder

  // Plain text labels - used for the board's own messages (and as a backup)
  lblTitle  = makeLabel(page, txtX, txtY + 2, TXT_W, 28, 0xFFFFFF, &lv_font_montserrat_20);
  lblArtist = makeLabel(page, txtX, txtY + 36, TXT_W, 22, 0xB3B3B3, NULL);
  setupPicture(txt, page, txtX, txtY);

  lblStatus = lv_label_create(page);
  lv_obj_set_style_text_color(lblStatus, lv_color_hex(0xAAAAAA), 0);
  lv_obj_set_width(lblStatus, 150);
  lv_label_set_long_mode(lblStatus, LV_LABEL_LONG_WRAP);
  lv_obj_set_pos(lblStatus, 12, 12);

  makeCornerLink(page, "Playlists " LV_SYMBOL_RIGHT, LV_ALIGN_TOP_RIGHT, 1);

  // --- Like (left of the album art) ---
  btnLike = lv_btn_create(page);
  lv_obj_set_size(btnLike, 150, 34);
  lv_obj_set_pos(btnLike, 12, 92);
  lv_obj_set_style_bg_color(btnLike, lv_color_hex(0x000000), 0);
  lv_obj_set_style_bg_opa(btnLike, LV_OPA_30, 0);
  lv_obj_set_style_shadow_width(btnLike, 0, 0);
  lv_obj_set_style_radius(btnLike, 17, 0);
  lv_obj_add_event_cb(btnLike, onLikeTapped, LV_EVENT_CLICKED, NULL);
  lblLike = lv_label_create(btnLike);
  lv_obj_set_style_text_color(lblLike, lv_color_hex(0xDDDDDD), 0);
  lv_label_set_text(lblLike, LV_SYMBOL_PLUS "  Like song");
  lv_obj_center(lblLike);

  // --- Volume (right of the album art) ---
  lblVolIcon = lv_label_create(page);
  lv_obj_set_style_text_color(lblVolIcon, lv_color_hex(0xDDDDDD), 0);
  lv_label_set_text(lblVolIcon, LV_SYMBOL_VOLUME_MAX);
  lv_obj_set_pos(lblVolIcon, 326, 62);

  volSlider = lv_slider_create(page);
  lv_obj_set_size(volSlider, 108, 8);
  lv_obj_set_pos(volSlider, 352, 68);
  lv_slider_set_range(volSlider, 0, 100);
  lv_obj_set_style_bg_color(volSlider, lv_color_hex(0xFFFFFF), LV_PART_INDICATOR);
  lv_obj_set_style_bg_color(volSlider, lv_color_hex(0xFFFFFF), LV_PART_KNOB);
  lv_obj_set_style_pad_all(volSlider, 5, LV_PART_KNOB);
  lv_obj_set_ext_click_area(volSlider, 14);   // easier to grab with a finger
  lv_obj_add_event_cb(volSlider, onVolumeEvent, LV_EVENT_ALL, NULL);

  btnVolTarget = lv_btn_create(page);
  lv_obj_set_size(btnVolTarget, 134, 28);
  lv_obj_set_pos(btnVolTarget, 326, 92);
  lv_obj_set_style_bg_color(btnVolTarget, lv_color_hex(0x000000), 0);
  lv_obj_set_style_bg_opa(btnVolTarget, LV_OPA_30, 0);
  lv_obj_set_style_shadow_width(btnVolTarget, 0, 0);
  lv_obj_set_style_radius(btnVolTarget, 14, 0);
  lv_obj_add_event_cb(btnVolTarget, onVolumeTargetTapped, LV_EVENT_CLICKED, NULL);
  lblVolTarget = lv_label_create(btnVolTarget);
  lv_obj_set_style_text_color(lblVolTarget, lv_color_hex(0xDDDDDD), 0);
  lv_obj_center(lblVolTarget);

  // --- Progress bar with times (under the song name) ---
  lblElapsed = makeLabel(page, 14, 210, 54, 18, 0xDDDDDD, NULL);
  progress = lv_slider_create(page);
  lv_obj_set_size(progress, 336, 6);
  lv_obj_set_pos(progress, 72, 216);
  lv_slider_set_range(progress, 0, 1000);
  lv_obj_set_style_bg_color(progress, lv_color_hex(0xFFFFFF), LV_PART_INDICATOR);
  lv_obj_set_style_bg_color(progress, lv_color_hex(0xFFFFFF), LV_PART_KNOB);
  lv_obj_set_style_pad_all(progress, 4, LV_PART_KNOB);
  lv_obj_set_ext_click_area(progress, 12);
  lv_obj_add_event_cb(progress, onProgressEvent, LV_EVENT_ALL, NULL);
  lblLength = makeLabel(page, 412, 210, 54, 18, 0xDDDDDD, NULL);

  // --- Buttons along the bottom, evenly spaced ---
  lv_obj_t *row = lv_obj_create(page);
  lv_obj_set_size(row, SCREEN_W - 20, 84);
  lv_obj_align(row, LV_ALIGN_BOTTOM_MID, 0, 0);
  lv_obj_set_style_bg_opa(row, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_width(row, 0, 0);
  lv_obj_set_style_pad_all(row, 0, 0);
  lv_obj_clear_flag(row, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
  lv_obj_set_flex_align(row, LV_FLEX_ALIGN_SPACE_EVENLY, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

  btnShuffle = makeIconButton(row, LV_SYMBOL_SHUFFLE, "SHUFFLE");
  makeRoundButton(row, 62, 0x333333, LV_SYMBOL_PREV, "PREV", NULL);
  makeRoundButton(row, 78, 0x1DB954, LV_SYMBOL_PLAY, "PLAYPAUSE", &lblPlayIcon);
  makeRoundButton(row, 62, 0x333333, LV_SYMBOL_NEXT, "NEXT", NULL);
  btnRepeat = makeIconButton(row, LV_SYMBOL_LOOP, "REPEAT");
  lblRepeat = lv_obj_get_child(btnRepeat, 0);
  lv_obj_set_style_text_color(lblPlayIcon, lv_color_hex(0x000000), 0);
  showModes();   // invisible until we know Spotify supports them

  volumeIsSpotify = prefs.getBool("volSpotify", false);
  showVolume();
  updateProgress();
}

// ============================================================
//  Page 2: playlists
// ============================================================

// Tapping a playlist's cover opens its song list.
static void onPlaylistTapped(lv_event_t *e) {
  int index = (int)(intptr_t)lv_event_get_user_data(e);
  beep(SOUND_NEXT);
  showSongList(index);
}

lv_obj_t *makeSmallButton(lv_obj_t *parent, int w, uint32_t color, const char *text, lv_event_cb_t cb) {
  lv_obj_t *btn = lv_btn_create(parent);
  lv_obj_set_size(btn, w, 32);
  lv_obj_set_style_bg_color(btn, lv_color_hex(color), 0);
  lv_obj_set_style_shadow_width(btn, 0, 0);
  lv_obj_set_style_radius(btn, 16, 0);
  lv_obj_add_event_cb(btn, cb, LV_EVENT_CLICKED, NULL);
  lv_obj_t *l = lv_label_create(btn);
  lv_label_set_text(l, text);
  lv_obj_set_style_text_color(l, lv_color_hex(color == 0x1DB954 ? 0x000000 : 0xFFFFFF), 0);
  lv_obj_center(l);
  return btn;
}

lv_obj_t *makeView(lv_obj_t *parent) {
  lv_obj_t *v = lv_obj_create(parent);
  lv_obj_set_size(v, SCREEN_W, SCREEN_H);
  lv_obj_set_pos(v, 0, 0);
  lv_obj_set_style_bg_opa(v, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_width(v, 0, 0);
  lv_obj_set_style_pad_all(v, 0, 0);
  lv_obj_set_style_radius(v, 0, 0);
  lv_obj_clear_flag(v, LV_OBJ_FLAG_SCROLLABLE);
  return v;
}

void buildPlaylistPage(lv_obj_t *page) {
  // ----- The grid of playlist covers -----
  gridView = makeView(page);

  lv_obj_t *title = lv_label_create(gridView);
  lv_obj_set_style_text_font(title, &lv_font_montserrat_20, 0);
  lv_obj_set_style_text_color(title, lv_color_hex(0xFFFFFF), 0);
  lv_label_set_text(title, "Playlists");
  lv_obj_set_pos(title, 16, 10);

  makeCornerLink(gridView, LV_SYMBOL_LEFT " Player", LV_ALIGN_TOP_RIGHT, 0);

  lv_obj_t *search = makeSmallButton(gridView, 110, 0x333333, LV_SYMBOL_KEYBOARD "  Search",
                                     [](lv_event_t *e) { showSearch(); });
  lv_obj_set_pos(search, 220, 6);

  // A grid of cards (cover + name). Scrolls up/down if there are lots.
  playlistGrid = lv_obj_create(gridView);
  lv_obj_set_size(playlistGrid, SCREEN_W, SCREEN_H - 44);
  lv_obj_set_pos(playlistGrid, 0, 44);
  lv_obj_set_style_bg_opa(playlistGrid, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_width(playlistGrid, 0, 0);
  lv_obj_set_style_pad_all(playlistGrid, 4, 0);
  lv_obj_set_style_pad_row(playlistGrid, 10, 0);
  lv_obj_set_flex_flow(playlistGrid, LV_FLEX_FLOW_ROW_WRAP);
  lv_obj_set_flex_align(playlistGrid, LV_FLEX_ALIGN_SPACE_EVENLY, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START);
  lv_obj_set_scroll_dir(playlistGrid, LV_DIR_VER);

  lblNoPlaylists = lv_label_create(gridView);
  lv_obj_set_style_text_color(lblNoPlaylists, lv_color_hex(0x888888), 0);
  lv_obj_set_width(lblNoPlaylists, 400);
  lv_obj_set_style_text_align(lblNoPlaylists, LV_TEXT_ALIGN_CENTER, 0);
  lv_label_set_long_mode(lblNoPlaylists, LV_LABEL_LONG_WRAP);
  lv_label_set_text(lblNoPlaylists, "No playlists yet.\nAdd them to playlists.txt on your PC.");
  lv_obj_center(lblNoPlaylists);

  for (int i = 0; i < MAX_PLAYLISTS; i++) {
    covers[i].w = covers[i].h = COVER_SIZE;
    covers[i].grey = false;
    covers[i].pixels = nullptr;
    covers[i].img = nullptr;
  }

  // ----- The song list of one playlist (hidden until you tap a cover) -----
  songView = makeView(page);
  lv_obj_add_flag(songView, LV_OBJ_FLAG_HIDDEN);

  lv_obj_t *back = makeSmallButton(songView, 44, 0x333333, LV_SYMBOL_LEFT, [](lv_event_t *e) { leaveSongList(); });
  lv_obj_set_pos(back, 10, 6);

  lblSongsTitle = lv_label_create(songView);
  lv_obj_set_style_text_font(lblSongsTitle, &lv_font_montserrat_20, 0);
  lv_obj_set_style_text_color(lblSongsTitle, lv_color_hex(0xFFFFFF), 0);
  lv_obj_set_width(lblSongsTitle, 214);
  lv_label_set_long_mode(lblSongsTitle, LV_LABEL_LONG_DOT);
  lv_obj_set_pos(lblSongsTitle, 64, 10);

  lv_obj_t *playAll = btnPlayAll = makeSmallButton(songView, 130, 0x1DB954, LV_SYMBOL_PLAY "  Play all", [](lv_event_t *e) {
    pc.printf("OPEN\t%d\n", songPlaylist);
    beep(SOUND_PLAY);
    lv_label_set_text(lblStatus, "Starting playlist...");
    goToPage(0);
  });
  lv_obj_set_pos(playAll, SCREEN_W - 140, 6);

  // Search inside this playlist
  lv_obj_t *find = makeSmallButton(songView, 52, 0x333333, "Find", [](lv_event_t *e) {
    int pl = songPlaylist == SEARCH_LIST ? searchScope : songPlaylist;
    if (pl >= 0) showSearchIn(pl);
    else showSearch();
  });
  lv_obj_set_pos(find, SCREEN_W - 196, 6);

  for (int k = 0; k < SONGS_PER_PAGE; k++) {
    rowBtns[k] = lv_btn_create(songView);
    lv_obj_set_size(rowBtns[k], ROW_W + 8, ROW_H + 2);
    lv_obj_set_pos(rowBtns[k], (SCREEN_W - ROW_W - 8) / 2, 44 + k * 40);
    lv_obj_set_style_bg_color(rowBtns[k], lv_color_hex(0x1E1E1E), 0);
    lv_obj_set_style_bg_color(rowBtns[k], lv_color_hex(0x333333), LV_STATE_PRESSED);
    lv_obj_set_style_shadow_width(rowBtns[k], 0, 0);
    lv_obj_set_style_radius(rowBtns[k], 6, 0);
    lv_obj_set_style_pad_all(rowBtns[k], 0, 0);
    lv_obj_clear_flag(rowBtns[k], LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(rowBtns[k], LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_event_cb(rowBtns[k], onSongTapped, LV_EVENT_CLICKED, (void *)(intptr_t)k);

    rows[k].w = ROW_W;
    rows[k].h = ROW_H;
    rows[k].grey = true;
    rows[k].pixels = nullptr;
    setupPicture(rows[k], rowBtns[k], 4, 1);
    lv_obj_clear_flag(rows[k].img, LV_OBJ_FLAG_CLICKABLE);

    // Little album cover (a grey square until the picture arrives)
    lv_obj_t *ph = lv_obj_create(rowBtns[k]);
    lv_obj_set_size(ph, SONG_ICON, SONG_ICON);
    lv_obj_set_pos(ph, 4 + ICON_X, 3);
    lv_obj_set_style_bg_color(ph, lv_color_hex(0x2A2A2A), 0);
    lv_obj_set_style_border_width(ph, 0, 0);
    lv_obj_set_style_radius(ph, 3, 0);
    lv_obj_clear_flag(ph, LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);
    icons[k].w = icons[k].h = SONG_ICON;
    icons[k].grey = false;
    icons[k].pixels = nullptr;
    setupPicture(icons[k], rowBtns[k], 4 + ICON_X, 3);
    lv_obj_clear_flag(icons[k].img, LV_OBJ_FLAG_CLICKABLE);
  }

  lblSongsInfo = lv_label_create(songView);
  lv_obj_set_style_text_color(lblSongsInfo, lv_color_hex(0x888888), 0);
  lv_obj_align(lblSongsInfo, LV_ALIGN_CENTER, 0, 0);

  // Bottom bar:  [Top] [up]   Page 3 / 40   [down] [End]
  lv_obj_t *top = makeSmallButton(songView, 74, 0x333333, LV_SYMBOL_UP " Top", [](lv_event_t *e) {
    if (songPage > 0) requestSongPage(0);
  });
  lv_obj_set_pos(top, 10, SCREEN_H - 34);
  lv_obj_t *up = makeSmallButton(songView, 64, 0x333333, LV_SYMBOL_UP, [](lv_event_t *e) {
    if (songPage > 0) requestSongPage(songPage - 1);
  });
  lv_obj_set_pos(up, 92, SCREEN_H - 34);
  lv_obj_t *down = makeSmallButton(songView, 64, 0x333333, LV_SYMBOL_DOWN, [](lv_event_t *e) {
    if (songPage < songPages - 1) requestSongPage(songPage + 1);
  });
  lv_obj_set_pos(down, SCREEN_W - 156, SCREEN_H - 34);
  lv_obj_t *end = makeSmallButton(songView, 74, 0x333333, LV_SYMBOL_DOWN " End", [](lv_event_t *e) {
    if (songPage < songPages - 1) requestSongPage(songPages - 1);
  });
  lv_obj_set_pos(end, SCREEN_W - 84, SCREEN_H - 34);

  lblPageNum = lv_label_create(songView);
  lv_obj_set_style_text_color(lblPageNum, lv_color_hex(0x888888), 0);
  lv_obj_align(lblPageNum, LV_ALIGN_BOTTOM_MID, 0, -10);
  lv_label_set_text(lblPageNum, "");

  // ----- Search: a text box and an on-screen keyboard -----
  searchView = makeView(page);
  lv_obj_add_flag(searchView, LV_OBJ_FLAG_HIDDEN);

  lv_obj_t *sback = makeSmallButton(searchView, 44, 0x333333, LV_SYMBOL_LEFT, [](lv_event_t *e) {
    if (searchScope >= 0) showSongList(searchScope); else showGrid();
  });
  lv_obj_set_pos(sback, 10, 6);

  lv_obj_t *stitle = lblSearchHint = lv_label_create(searchView);
  lv_obj_set_style_text_color(stitle, lv_color_hex(0xB3B3B3), 0);
  lv_obj_set_width(stitle, SCREEN_W - 80);
  lv_label_set_long_mode(stitle, LV_LABEL_LONG_DOT);
  lv_label_set_text(stitle, "Search all your playlists (song or artist)");
  lv_obj_set_pos(stitle, 64, 14);

  searchBox = lv_textarea_create(searchView);
  lv_textarea_set_one_line(searchBox, true);
  lv_textarea_set_placeholder_text(searchBox, "e.g. yoasobi");
  lv_obj_set_size(searchBox, SCREEN_W - 20, 44);
  lv_obj_set_pos(searchBox, 10, 46);
  lv_obj_set_style_text_font(searchBox, &lv_font_montserrat_20, 0);

  keyboard = lv_keyboard_create(searchView);
  lv_obj_set_size(keyboard, SCREEN_W, SCREEN_H - 100);
  lv_obj_align(keyboard, LV_ALIGN_BOTTOM_MID, 0, 0);
  lv_keyboard_set_textarea(keyboard, searchBox);
  lv_obj_add_event_cb(keyboard, [](lv_event_t *e) {
    if (lv_event_get_code(e) == LV_EVENT_READY) {          // the tick / Enter key
      String query = lv_textarea_get_text(searchBox);
      query.trim();
      if (query.length() == 0) return;
      beep(SOUND_NEXT);
      songPlaylist = SEARCH_LIST;
      songPage = 0;
      songPages = 1;
      String title = "\"" + query + "\"";
      if (searchScope >= 0) title += " in " + playlistNames[searchScope];
      lv_label_set_text(lblSongsTitle, title.c_str());
      lv_label_set_text(lblPageNum, "");
      lv_obj_add_flag(btnPlayAll, LV_OBJ_FLAG_HIDDEN);
      lv_obj_add_flag(searchView, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(songView, LV_OBJ_FLAG_HIDDEN);
      hideSongRows();
      lv_label_set_text(lblSongsInfo, "Searching...");
      if (searchScope >= 0) pc.printf("FIND\t%d\t", searchScope);
      else pc.print("SEARCH\t");
      pc.println(query);
    } else if (lv_event_get_code(e) == LV_EVENT_CANCEL) {  // the keyboard's close key
      if (searchScope >= 0) showSongList(searchScope); else showGrid();
    }
  }, LV_EVENT_ALL, NULL);
}

void showSearch() {
  searchScope = -1;
  lv_label_set_text(lblSearchHint, "Search all your playlists (song or artist)");
  lv_obj_add_flag(gridView, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(songView, LV_OBJ_FLAG_HIDDEN);
  lv_obj_clear_flag(searchView, LV_OBJ_FLAG_HIDDEN);
  lv_textarea_set_text(searchBox, "");
}

void showSearchIn(int playlist) {
  searchScope = playlist;
  String hint = "Search in " + playlistNames[playlist] + " (song or artist)";
  lv_label_set_text(lblSearchHint, hint.c_str());
  lv_obj_add_flag(gridView, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(songView, LV_OBJ_FLAG_HIDDEN);
  lv_obj_clear_flag(searchView, LV_OBJ_FLAG_HIDDEN);
  lv_textarea_set_text(searchBox, "");
}

// Back button on the song list: search results inside a playlist go back to that playlist
void leaveSongList() {
  if (songPlaylist == SEARCH_LIST && searchScope >= 0) showSongList(searchScope);
  else showGrid();
}

void hideSongRows() {
  for (int k = 0; k < SONGS_PER_PAGE; k++) {
    lv_obj_add_flag(rowBtns[k], LV_OBJ_FLAG_HIDDEN);
    if (icons[k].img) lv_obj_add_flag(icons[k].img, LV_OBJ_FLAG_HIDDEN);
  }
}

void requestSongPage(int page) {
  hideSongRows();
  lv_label_set_text(lblSongsInfo, "Loading songs...");
  if (songPlaylist == SEARCH_LIST) pc.printf("RESULTS\t%d\n", page);
  else pc.printf("SONGS\t%d\t%d\n", songPlaylist, page);
}

void showSongList(int playlist) {
  songPlaylist = playlist;
  songPage = 0;
  songPages = 1;
  lv_label_set_text(lblSongsTitle, playlistNames[playlist].c_str());
  lv_label_set_text(lblPageNum, "");
  lv_obj_clear_flag(btnPlayAll, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(gridView, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(searchView, LV_OBJ_FLAG_HIDDEN);
  lv_obj_clear_flag(songView, LV_OBJ_FLAG_HIDDEN);
  requestSongPage(0);
}

void showGrid() {
  songPlaylist = -1;
  lv_obj_add_flag(songView, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(searchView, LV_OBJ_FLAG_HIDDEN);
  lv_obj_clear_flag(gridView, LV_OBJ_FLAG_HIDDEN);
}

static void onSongTapped(lv_event_t *e) {
  int k = (int)(intptr_t)lv_event_get_user_data(e);
  int number = songPage * SONGS_PER_PAGE + k;
  if (songPlaylist == SEARCH_LIST) pc.printf("PLAYRESULT\t%d\n", number);
  else pc.printf("PLAYSONG\t%d\t%d\n", songPlaylist, number);
  beep(SOUND_PLAY);
  lv_label_set_text(lblStatus, "Starting song...");
  goToPage(0);   // back to the player
}

void clearPlaylists() {
  showGrid();
  lv_obj_clean(playlistGrid);   // removes all the cards
  for (int i = 0; i < MAX_PLAYLISTS; i++) covers[i].img = nullptr;
  playlistCount = 0;
  lv_obj_clear_flag(lblNoPlaylists, LV_OBJ_FLAG_HIDDEN);
}

void addPlaylist(int index, const String &name) {
  if (index < 0 || index >= MAX_PLAYLISTS) return;
  playlistNames[index] = name;

  lv_obj_t *card = lv_btn_create(playlistGrid);
  lv_obj_set_size(card, 104, 124);
  lv_obj_set_style_bg_color(card, lv_color_hex(0x1E1E1E), 0);
  lv_obj_set_style_bg_color(card, lv_color_hex(0x333333), LV_STATE_PRESSED);
  lv_obj_set_style_shadow_width(card, 0, 0);
  lv_obj_set_style_radius(card, 10, 0);
  lv_obj_set_style_pad_all(card, 0, 0);
  lv_obj_clear_flag(card, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_add_event_cb(card, onPlaylistTapped, LV_EVENT_CLICKED, (void *)(intptr_t)index);

  // Grey square with a note, until the cover picture arrives
  lv_obj_t *ph = lv_obj_create(card);
  lv_obj_set_size(ph, COVER_SIZE, COVER_SIZE);
  lv_obj_set_pos(ph, 12, 8);
  lv_obj_set_style_bg_color(ph, lv_color_hex(0x282828), 0);
  lv_obj_set_style_border_width(ph, 0, 0);
  lv_obj_set_style_radius(ph, 6, 0);
  lv_obj_clear_flag(ph, LV_OBJ_FLAG_SCROLLABLE | LV_OBJ_FLAG_CLICKABLE);
  lv_obj_t *note = lv_label_create(ph);
  lv_obj_set_style_text_color(note, lv_color_hex(0x777777), 0);
  lv_label_set_text(note, LV_SYMBOL_AUDIO);
  lv_obj_center(note);

  setupPicture(covers[index], card, 12, 8);
  lv_obj_clear_flag(covers[index].img, LV_OBJ_FLAG_CLICKABLE);

  lv_obj_t *label = makeLabel(card, 2, 92, 100, 30, 0xFFFFFF, NULL);
  lv_label_set_text(label, name.c_str());

  playlistCount++;
  lv_obj_add_flag(lblNoPlaylists, LV_OBJ_FLAG_HIDDEN);
}

// ============================================================
//  Whole screen
// ============================================================

// The clock: a full-screen layer on top of everything, shown when nothing has played for a while.
void buildClock() {
  clockView = lv_obj_create(lv_layer_top());
  lv_obj_set_size(clockView, SCREEN_W, SCREEN_H);
  lv_obj_set_pos(clockView, 0, 0);
  lv_obj_set_style_bg_color(clockView, lv_color_hex(0x050505), 0);
  lv_obj_set_style_bg_opa(clockView, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(clockView, 0, 0);
  lv_obj_set_style_radius(clockView, 0, 0);
  lv_obj_set_style_pad_all(clockView, 0, 0);
  lv_obj_clear_flag(clockView, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_add_flag(clockView, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_event_cb(clockView, [](lv_event_t *e) {   // tap the clock to go back to the player
    clockDismissedAt = millis();
    hideClock();
  }, LV_EVENT_CLICKED, NULL);

  setupPicture(clockPic, clockView, (SCREEN_W - CLK_W) / 2, 14);
  lv_obj_clear_flag(clockPic.img, LV_OBJ_FLAG_CLICKABLE);

  // Bottom strip: last played (cover + name + Resume) on the left, weather on the right
  const int stripX = (SCREEN_W - STRIP_W) / 2;
  lv_obj_t *line = lv_obj_create(clockView);           // a thin divider
  lv_obj_set_size(line, STRIP_W, 1);
  lv_obj_set_pos(line, stripX, STRIP_Y - 10);
  lv_obj_set_style_bg_color(line, lv_color_hex(0x2A2A2A), 0);
  lv_obj_set_style_border_width(line, 0, 0);
  lv_obj_clear_flag(line, LV_OBJ_FLAG_CLICKABLE);

  setupPicture(clockStrip, clockView, stripX, STRIP_Y);
  lv_obj_clear_flag(clockStrip.img, LV_OBJ_FLAG_CLICKABLE);

  clockArt = lv_img_create(clockView);                 // the same album art, shrunk to 56 px
  lv_img_set_src(clockArt, &art.dsc);
  lv_img_set_pivot(clockArt, 0, 0);
  lv_img_set_zoom(clockArt, 256 * 56 / ART_W);
  lv_obj_set_pos(clockArt, stripX, STRIP_Y + 4);
  lv_obj_clear_flag(clockArt, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_add_flag(clockArt, LV_OBJ_FLAG_HIDDEN);

  btnResume = lv_btn_create(clockView);
  lv_obj_set_size(btnResume, 104, 30);
  lv_obj_set_pos(btnResume, stripX + 66, STRIP_Y + 62);
  lv_obj_set_style_bg_color(btnResume, lv_color_hex(0x1DB954), 0);
  lv_obj_set_style_shadow_width(btnResume, 0, 0);
  lv_obj_set_style_radius(btnResume, 15, 0);
  lv_obj_add_event_cb(btnResume, [](lv_event_t *e) {
    lv_event_stop_bubbling(e);   // don't also count as "tap the clock"
    pc.println("PLAYPAUSE");
    isPlaying = true;
    setPlayIcon(true);
    beep(SOUND_PLAY);
    hideClock();
  }, LV_EVENT_CLICKED, NULL);
  lv_obj_t *rl = lv_label_create(btnResume);
  lv_obj_set_style_text_color(rl, lv_color_hex(0x000000), 0);
  lv_label_set_text(rl, LV_SYMBOL_PLAY "  Resume");
  lv_obj_center(rl);
  lv_obj_add_flag(btnResume, LV_OBJ_FLAG_HIDDEN);

  lblStats = lv_label_create(clockView);
  lv_obj_set_style_text_color(lblStats, lv_color_hex(0x6A6A6A), 0);
  lv_label_set_text(lblStats, "");
  lv_obj_align(lblStats, LV_ALIGN_BOTTOM_MID, 0, -4);
  lv_obj_clear_flag(lblStats, LV_OBJ_FLAG_CLICKABLE);
}

// The "last played" part only makes sense if there's a paused song (its cover is showing).
void updateClockLastPlayed() {
  bool show = art.img && !lv_obj_has_flag(art.img, LV_OBJ_FLAG_HIDDEN);
  if (show) {
    lv_obj_clear_flag(clockArt, LV_OBJ_FLAG_HIDDEN);
    lv_obj_clear_flag(btnResume, LV_OBJ_FLAG_HIDDEN);
    lv_obj_invalidate(clockArt);
  } else {
    lv_obj_add_flag(clockArt, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(btnResume, LV_OBJ_FLAG_HIDDEN);
  }
}

void showClock() {
  if (clockShown) return;
  clockShown = true;
  updateClockLastPlayed();
  lv_obj_clear_flag(clockView, LV_OBJ_FLAG_HIDDEN);
}

void hideClock() {
  if (!clockShown) return;
  clockShown = false;
  lv_obj_add_flag(clockView, LV_OBJ_FLAG_HIDDEN);
}

void buildUI() {
  lv_obj_t *scr = lv_scr_act();
  lv_obj_set_style_bg_color(scr, lv_color_hex(0x121212), 0);   // dark grey

  // Two pages side by side - swipe left/right to move between them.
  pages = lv_tileview_create(scr);
  bgFrom = bgTo = bgNow = lv_color_hex(0x121212);
  lv_obj_set_style_bg_color(pages, bgNow, 0);
  lv_obj_set_scrollbar_mode(pages, LV_SCROLLBAR_MODE_OFF);
  playerPage   = lv_tileview_add_tile(pages, 0, 0, LV_DIR_RIGHT);
  playlistPage = lv_tileview_add_tile(pages, 1, 0, LV_DIR_LEFT);

  buildPlayerPage(playerPage);
  buildPlaylistPage(playlistPage);
  buildClock();
}

void showMessage(const char *status, const String &title, const String &subtitle) {
  lv_label_set_text(lblStatus, status);
  String t = title, s = subtitle;
  setText(lblTitle, shownTitle, t);
  setText(lblArtist, shownArtist, s);
  showPicture(txt, false);
  showPicture(art, false);
  setPlayIcon(false);
}

void showWaitingForPC() {
  songLenMs = 0;
  if (progress) updateProgress();
  setBackground(lv_color_hex(0x121212));
  String how = "Run spotify_helper.py on your PC";
  if (pc.wifiConnected()) how += "  -  WiFi: " + pc.address();
  else if (pc.wifiEnabled()) {
    switch (WiFi.status()) {
      case WL_NO_SSID_AVAIL:  how += "  -  WiFi: network not found (check the name)"; break;
      case WL_CONNECT_FAILED: how += "  -  WiFi: couldn't join (check the password)"; break;
      default:                how += "  -  joining WiFi..."; break;
    }
  }
  showMessage("Waiting for PC...", "Not connected", how);
}

// ============================================================
//  Messages from the PC
// ============================================================

void sendInfo();

void handleLine(const String &line) {
  lastMessageAt = millis();
  if (!helperConnected) {
    helperConnected = true;
    sendInfo();   // memory + WiFi report for the helper's log, every time it (re)connects
  }

  if (line.startsWith("NP\t")) {
    // "NP<tab>playing<tab>title<tab>artist"
    int a = line.indexOf('\t', 3);
    int b = (a < 0) ? -1 : line.indexOf('\t', a + 1);
    if (a < 0 || b < 0) return;   // badly formed line, ignore it

    isPlaying = line.substring(3, a) == "1";
    // Backup text, only visible until the PC's song-name picture arrives.
    String title = line.substring(a + 1, b), artist = line.substring(b + 1);
    setText(lblTitle, shownTitle, title);
    setText(lblArtist, shownArtist, artist);
    setPlayIcon(isPlaying);
    lv_label_set_text(lblStatus, isPlaying ? "Now playing" : "Paused");

  } else if (line == "NONE") {
    isPlaying = false;
    songLenMs = 0;
    updateProgress();
    setBackground(lv_color_hex(0x121212));
    showMessage("Connected to PC", "Nothing playing", "Open Spotify on your PC and play something");

  } else if (line.startsWith("IMG\t")) {
    if (line == "IMG\tART") receiving = &art;
    else if (line == "IMG\tTXT") receiving = &txt;
    else if (line == "IMG\tCLK") receiving = &clockPic;
    else if (line == "IMG\tCLB") receiving = &clockStrip;
    else if (line.startsWith("IMG\tSR")) {
      int k = line.substring(6).toInt();
      receiving = (k >= 0 && k < SONGS_PER_PAGE) ? &rows[k] : nullptr;
    } else if (line.startsWith("IMG\tSI")) {
      int k = line.substring(6).toInt();
      receiving = (k >= 0 && k < SONGS_PER_PAGE) ? &icons[k] : nullptr;
    } else {
      int i = line.substring(6).toInt();
      receiving = (i >= 0 && i < MAX_PLAYLISTS && covers[i].img) ? &covers[i] : nullptr;
    }
    if (receiving && !receiving->pixels) {   // no memory for this picture
      receiving = nullptr;
      lv_label_set_text(lblStatus, "Out of memory for pictures!\nTools > PSRAM > OPI PSRAM");
    }
    received = 0;
    lastByteAt = millis();
    // If we can't take this picture, the PC will give up after a moment and carry on.

  } else if (line == "NOART") {
    showPicture(art, false);

  } else if (line.startsWith("TL\t")) {
    // "TL<tab>position ms<tab>length ms"
    int a = line.indexOf('\t', 3);
    if (a < 0) return;
    songPosMs = line.substring(3, a).toInt();
    songLenMs = line.substring(a + 1).toInt();
    songPosAt = millis();
    updateProgress();

  } else if (line.startsWith("VOL\t")) {
    int a = line.indexOf('\t', 4);
    if (a < 0) return;
    volPC = line.substring(4, a).toInt();
    volSpotify = line.substring(a + 1).toInt();
    showVolume();

  } else if (line.startsWith("MODES\t")) {
    int a = line.indexOf('\t', 6);
    if (a < 0) return;
    shuffleMode = line.substring(6, a).toInt();
    repeatMode = line.substring(a + 1).toInt();
    showModes();

  } else if (line.startsWith("LIKED\t")) {
    showLikeResult(line.substring(6));

  } else if (line.startsWith("STATS\t")) {
    lv_label_set_text(lblStats, line.substring(6).c_str());

  } else if (line.startsWith("BG\t")) {
    setBackground(lv_color_hex(strtoul(line.substring(3).c_str(), NULL, 16)));

  } else if (line == "SLWAIT") {
    lv_label_set_text(lblSongsInfo, "Getting the song list from Spotify...");

  } else if (line.startsWith("SL\t")) {
    // "SL<tab>playlist<tab>page<tab>pages<tab>rows"
    int v[4], start = 3;
    for (int i = 0; i < 4; i++) {
      int end = line.indexOf('\t', start);
      v[i] = line.substring(start, end < 0 ? line.length() : end).toInt();
      start = end + 1;
    }
    if (v[0] != songPlaylist) return;   // you've moved on to another playlist
    songPage = v[1];
    songPages = v[2];
    hideSongRows();
    lv_label_set_text(lblSongsInfo, v[3] > 0 ? "" :
                      songPlaylist == SEARCH_LIST ? "No songs found. (Japanese titles: try the artist's name)"
                                                  : "This playlist has no songs.");
    lv_label_set_text_fmt(lblPageNum, "Page %d / %d", songPage + 1, songPages);

  } else if (line == "PLCLEAR") {
    clearPlaylists();

  } else if (line.startsWith("PL\t")) {
    // "PL<tab>index<tab>name"
    int a = line.indexOf('\t', 3);
    if (a < 0) return;
    addPlaylist(line.substring(3, a).toInt(), line.substring(a + 1));
  }
}

void readFromPC() {
  while (pc.available()) {
    if (receiving) {
      // Picture bytes go straight into that picture's buffer.
      uint32_t total = pictureBytes(*receiving);
      size_t n = pc.readBytes(receiving->pixels + received, min((uint32_t)pc.available(), total - received));
      if (n == 0) break;
      received += n;
      lastByteAt = millis();
      if (received % CHUNK == 0 || received == total) pc.println("ACK");
      if (received == total) {
        showPicture(*receiving, true);
        receiving = nullptr;
      }
      continue;
    }

    char c = pc.read();
    if (c == '\n') {
      handleLine(rxLine);
      rxLine = "";
    } else if (c != '\r' && rxLine.length() < 400) {
      rxLine += c;
    }
  }

  // If a picture stops arriving halfway, give up on it.
  if (receiving && millis() - lastByteAt > 1500) {
    showPicture(*receiving, false);
    receiving = nullptr;
  }
}

// ============================================================
//  setup() runs once, loop() runs forever
// ============================================================

// Report for the helper's log: memory, and the board's WiFi address
// (the helper saves the address so it can find the board over WiFi later).
void sendInfo() {
  char info[160];
  snprintf(info, sizeof(info), "INFO\tpsram=%u KB\tfree=%u KB\twifi=%s\n",
           (unsigned)(ESP.getPsramSize() / 1024), (unsigned)(ESP.getFreeHeap() / 1024),
           pc.wifiConnected() ? pc.address().c_str() : (pc.wifiEnabled() ? "connecting" : "off"));
  pc.sendToAll(info);
}

void setup() {
  Serial.setRxBufferSize(CHUNK + 4096);   // room for a whole picture piece
  Serial.begin(115200);
  pc.begin(WIFI_NAME, WIFI_PASSWORD);
  screen.init();
#if BUTTON_SOUNDS
  soundsBegin(SOUND_VOLUME);
#endif
  prefs.begin("mediahud", false);
  screen.setBrightness(SCREEN_BRIGHTNESS);
  lastPlayingAt = millis();
  buildUI();
  if (!art.pixels || !txt.pixels) Serial.println("Not enough memory for pictures!");
  showWaitingForPC();
}

void loop() {
  screen.routine();   // draw the screen and read touches
  pc.loop();          // keep WiFi going
  readFromPC();

  // While waiting for the PC, refresh the message when WiFi connects (to show the address)
  static bool wasOnWifi = false;
  static int lastWifiStatus = -1;
  if (pc.wifiConnected() != wasOnWifi) {
    wasOnWifi = pc.wifiConnected();
    sendInfo();   // tell the helper our WiFi address
  }
  if (pc.wifiEnabled() && WiFi.status() != lastWifiStatus) {
    lastWifiStatus = WiFi.status();
    if (!helperConnected) showWaitingForPC();   // show the WiFi state on the waiting screen
  }

  // The helper sends an update at least every 2 seconds. If it goes quiet, say so.
  if (helperConnected && !receiving && millis() - lastMessageAt > 5000) {
    helperConnected = false;
    showWaitingForPC();
  }

  // Move the progress bar along (4 times a second is plenty)
  static unsigned long lastProgressAt = 0;
  if (millis() - lastProgressAt > 250) {
    lastProgressAt = millis();
    updateProgress();
  }

  // Clock: shown after a while with nothing playing (and not straight after you tapped it away)
#if CLOCK_AFTER_SECONDS > 0
  {
    unsigned long quietSince = max(max(lastPlayingAt, screen.lastTouchMs()), clockDismissedAt);
    bool idle = helperConnected && !isPlaying && millis() - quietSince > CLOCK_AFTER_SECONDS * 1000UL;
    if (idle && clockReady) showClock();
    else if (isPlaying || !helperConnected) hideClock();
  }
#endif

  // Screen sleep: dark after a while with nothing playing, back on when music plays.
#if SCREEN_SLEEP_SECONDS > 0
  if (isPlaying) lastPlayingAt = millis();
  unsigned long lastActive = max(lastPlayingAt, screen.lastTouchMs());
  if (isPlaying && screen.sleeping()) screen.wake();
  else if (!isPlaying && !screen.sleeping() && millis() - lastActive > SCREEN_SLEEP_SECONDS * 1000UL) screen.sleep();
#endif

  // While waiting, say hello now and then so the helper re-sends everything
  // (e.g. after the board restarts but the helper kept running).
  if (!helperConnected && millis() - lastHelloAt > 2000) {
    lastHelloAt = millis();
    pc.sendToAll("HELLO\n");
    sendInfo();
  }

  delay(2);
}
