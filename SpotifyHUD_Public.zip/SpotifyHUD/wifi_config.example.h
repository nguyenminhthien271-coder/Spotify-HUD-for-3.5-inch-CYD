// ============================================================
//  WiFi settings.
//  FIRST TIME: make a copy of this file called  wifi_config.h  (same folder) and fill that in.
//  Updates only ever include this example file, so your wifi_config.h is never overwritten.
//  Keep the quote marks. Leave WIFI_NAME as "" to use only the USB cable.
//  The board needs a 2.4 GHz network (your TP-Link AC1200 has one).
//  Don't share this file with anyone (it has your WiFi password).
// ============================================================
#pragma once

#define WIFI_NAME     ""
#define WIFI_PASSWORD ""
