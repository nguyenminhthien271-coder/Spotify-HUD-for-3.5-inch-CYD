// The connection to the PC helper: the USB cable, or WiFi (whichever the helper is using).
#include "pc_link.h"
#include <ESPmDNS.h>

PcLink pc;

void PcLink::begin(const char *ssid, const char *password) {
  useWifi = ssid && ssid[0];
  if (!useWifi) return;
  WiFi.mode(WIFI_STA);
  WiFi.setHostname("mediahud");
  WiFi.setAutoReconnect(true);
  WiFi.setSleep(false);   // WiFi power saving adds a delay to every message - turn it off
  WiFi.begin(ssid, password);   // connects in the background
}

bool PcLink::wifiConnected() { return useWifi && WiFi.status() == WL_CONNECTED; }

String PcLink::address() { return wifiConnected() ? WiFi.localIP().toString() : String(""); }

void PcLink::loop() {
  if (!useWifi) return;
  if (!serverStarted && wifiConnected()) {
    server.begin();
    server.setNoDelay(true);
    // Lets the PC find the board as "mediahud.local" without knowing its address.
    if (MDNS.begin("mediahud")) MDNS.addService("mediahud", "tcp", PC_LINK_PORT);
    serverStarted = true;
  }
  if (serverStarted) {
    WiFiClient incoming = server.accept();
    if (incoming) {                 // the helper connected (again) - use the newest connection
      client.stop();
      client = incoming;
      client.setNoDelay(true);      // send small messages straight away
      active = WIFI_LINK;
    }
  }
}

int PcLink::available() {
  // Whichever link has data is the one the helper is using.
  int n = Serial.available();
  if (n > 0) { active = USB_LINK; return n; }
  if (client && client.connected()) {
    n = client.available();
    if (n > 0) { active = WIFI_LINK; return n; }
  }
  return 0;
}

int PcLink::read() {
  return active == WIFI_LINK ? client.read() : Serial.read();
}

size_t PcLink::readBytes(uint8_t *buffer, size_t length) {
  int r = active == WIFI_LINK ? client.read(buffer, length) : Serial.read(buffer, length);
  return r > 0 ? (size_t)r : 0;
}

size_t PcLink::write(uint8_t c) { return write(&c, 1); }

size_t PcLink::write(const uint8_t *buffer, size_t size) {
  if (active == WIFI_LINK && client.connected()) return client.write(buffer, size);
  return Serial.write(buffer, size);
}

void PcLink::sendToAll(const String &text) {
  if (Serial) Serial.print(text);                   // only if a PC has the USB port open
  if (client && client.connected()) client.print(text);
}
