// Little beeps for the buttons, played through the board's speaker connector.
#pragma once
#include <Arduino.h>

enum Sound { SOUND_PLAY, SOUND_PAUSE, SOUND_NEXT, SOUND_PREV };

// volume: 0 (silent) to 100 (loud)
void soundsBegin(int volume);

// Starts the sound and returns straight away (it plays in the background).
void playSound(Sound s);
