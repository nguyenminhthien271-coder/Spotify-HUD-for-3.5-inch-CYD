// Little beeps for the buttons, played through the board's speaker connector.
// Pin numbers are from Freenove's Sketch_07.1_Music (FNK0104N section).
#include "sounds.h"
#include <Wire.h>
#include "ESP_I2S.h"
#include "es8311.h"

#define I2S_MCK 17
#define I2S_BCK 18
#define I2S_DIN 16
#define I2S_DOUT 15
#define I2S_WS 21
#define AMP_ENABLE 1      // speaker amplifier: LOW = on
#define I2C_SCL 39        // shared with the touchscreen
#define I2C_SDA 38

#define SAMPLE_RATE 16000

static I2SClass i2s;
static QueueHandle_t soundQueue = nullptr;
static bool ready = false;

// One note: frequency (Hz) and length (milliseconds). Frequency 0 = short silence.
struct Note { uint16_t freq, ms; };

// Pause = falling notes, play = rising notes,
// next = two quick rising ticks, previous = two quick falling ticks.
static const Note PLAY_NOTES[]  = {{523, 70}, {784, 90}};
static const Note PAUSE_NOTES[] = {{784, 70}, {523, 90}};
static const Note NEXT_NOTES[]  = {{988, 40}, {0, 25}, {1319, 50}};
static const Note PREV_NOTES[]  = {{1319, 40}, {0, 25}, {988, 50}};

static void playNote(const Note &n) {
  const int total = SAMPLE_RATE * n.ms / 1000;
  const int fade = SAMPLE_RATE * 6 / 1000;   // 6 ms fade in/out, so it doesn't click
  int16_t frame[2 * 64];                     // 64 stereo samples at a time
  float phase = 0, step = 2.0f * PI * n.freq / SAMPLE_RATE;

  for (int i = 0; i < total; ) {
    int count = min(64, total - i);
    for (int k = 0; k < count; k++, i++) {
      float env = 1.0f;
      if (i < fade) env = (float)i / fade;
      else if (i > total - fade) env = (float)(total - i) / fade;
      int16_t v = n.freq ? (int16_t)(sinf(phase) * 9000.0f * env) : 0;
      phase += step;
      if (phase > 2.0f * PI) phase -= 2.0f * PI;
      frame[2 * k] = v;       // left
      frame[2 * k + 1] = v;   // right
    }
    i2s.write((uint8_t *)frame, count * 4);
  }
}

// Runs in the background so the screen doesn't freeze while a sound plays.
static void soundTask(void *) {
  Sound s;
  while (true) {
    if (xQueueReceive(soundQueue, &s, portMAX_DELAY) != pdTRUE) continue;
    const Note *notes; int count;
    switch (s) {
      case SOUND_PLAY:  notes = PLAY_NOTES;  count = 2; break;
      case SOUND_PAUSE: notes = PAUSE_NOTES; count = 2; break;
      case SOUND_NEXT:  notes = NEXT_NOTES;  count = 3; break;
      default:          notes = PREV_NOTES;  count = 3; break;
    }
    for (int i = 0; i < count; i++) playNote(notes[i]);
    playNote({0, 30});   // a little silence to finish cleanly
  }
}

void soundsBegin(int volume) {
  pinMode(AMP_ENABLE, OUTPUT);
  digitalWrite(AMP_ENABLE, LOW);   // turn the speaker amplifier on

  Wire.begin(I2C_SDA, I2C_SCL);    // already started by the touchscreen - that's fine

  i2s.setPins(I2S_BCK, I2S_WS, I2S_DOUT, I2S_DIN, I2S_MCK);
  if (!i2s.begin(I2S_MODE_STD, SAMPLE_RATE, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO, I2S_STD_SLOT_BOTH)) {
    Serial.println("Sound: couldn't start I2S");
    return;
  }

  // Set up the audio chip. The I2S library sends it a clock of 256 x the sample rate.
  es8311_handle_t codec = es8311_create(I2C_NUM_0, ES8311_ADDRESS_0);
  if (!codec) { Serial.println("Sound: audio chip not found"); return; }
  const es8311_clock_config_t clk = {
    .mclk_inverted = false,
    .sclk_inverted = false,
    .mclk_from_mclk_pin = true,
    .mclk_frequency = SAMPLE_RATE * 256,
    .sample_frequency = SAMPLE_RATE
  };
  if (es8311_init(codec, &clk, ES8311_RESOLUTION_16, ES8311_RESOLUTION_16) != ESP_OK) {
    Serial.println("Sound: audio chip setup failed");
    return;
  }
  es8311_voice_volume_set(codec, constrain(volume, 0, 100), NULL);

  soundQueue = xQueueCreate(4, sizeof(Sound));
  xTaskCreate(soundTask, "sounds", 4096, NULL, 1, NULL);
  ready = true;
}

void playSound(Sound s) {
  if (!ready) return;
  xQueueReset(soundQueue);          // a new tap replaces any sound still waiting
  xQueueSend(soundQueue, &s, 0);
}
