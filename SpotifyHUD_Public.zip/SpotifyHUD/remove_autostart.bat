@echo off
rem Stops the helper starting by itself. (To stop it right now: right-click the icon, Quit.)
python "%~dp0spotify_helper.py" --uninstall
pause
