// The connection to the PC helper: the USB cable, or WiFi (whichever the helper is using).
#pragma once
#include <Arduino.h>
#include <WiFi.h>

#define PC_LINK_PORT 5050   // must match BOARD_PORT in spotify_helper.py

class PcLink : public Print {
public:
  void begin(const char *ssid, const char *password);   // ssid "" = USB only
  void loop();                    // keeps WiFi going - call often

  int available();                // bytes waiting from the PC
  int read();                     // read one byte
  size_t readBytes(uint8_t *buffer, size_t length);

  size_t write(uint8_t c) override;                      // send to the PC (on the link it's using)
  size_t write(const uint8_t *buffer, size_t size) override;
  void sendToAll(const String &text);                    // e.g. HELLO, on USB and WiFi

  bool wifiEnabled() { return useWifi; }
  bool wifiConnected();
  bool onWifi() { return active == WIFI_LINK && client.connected(); }
  String address();               // the board's WiFi address, e.g. 192.168.0.42

private:
  enum { USB_LINK, WIFI_LINK };
  int active = USB_LINK;
  bool useWifi = false, serverStarted = false;
  WiFiServer server{PC_LINK_PORT};
  WiFiClient client;
};

extern PcLink pc;
