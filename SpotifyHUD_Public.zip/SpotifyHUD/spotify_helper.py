"""
Spotify helper for the Spotify HUD board (Windows only).

It reads the song that's playing (and its album art) from Windows' media
controls and sends it to the board over USB. When you tap a button on the
board, it pauses / skips.

Setup (one time), in a Command Prompt:
    pip install pyserial pillow pystray comtypes pycaw winrt-runtime winrt-Windows.Foundation winrt-Windows.Media winrt-Windows.Media.Control winrt-Windows.Storage.Streams

Ways to run it:
    start_helper.bat          - runs quietly in the background, with an icon by the clock
    install_autostart.bat     - also starts it automatically every time you log in
    remove_autostart.bat      - stops it starting automatically
    python spotify_helper.py  - runs in this window, so you can watch what it's doing

Right-click the icon by the clock to pause it (do this before uploading code
from the Arduino IDE), see its log, or quit.
"""

import asyncio
import hashlib
import io
import math
import os
import socket
import subprocess
import sys
import colorsys
import concurrent.futures
import select
import datetime
import json
import re
import unicodedata
import threading
import time
import urllib.parse
import urllib.request

import serial
from serial.tools import list_ports
from PIL import Image, ImageDraw, ImageFont, ImageOps
from winrt.windows.media.control import (
    GlobalSystemMediaTransportControlsSessionManager as MediaManager,
    GlobalSystemMediaTransportControlsSessionPlaybackStatus as PlaybackStatus,
)
from winrt.windows.storage.streams import Buffer, InputStreamOptions

try:
    from winrt.windows.media import MediaPlaybackAutoRepeatMode as RepeatMode   # for the repeat button
except ImportError:
    RepeatMode = None

from spotify_remote import SpotifyRemote

try:
    import psutil           # CPU / memory use for the clock screen (comes with pycaw)
except ImportError:
    psutil = None

try:
    import pystray          # the icon by the clock (optional)
except Exception:
    pystray = None

ESP32_USB_VENDOR_ID = 0x303A   # Espressif's USB ID - used to find the board automatically
BOARD_PORT = 5050              # WiFi: must match PC_LINK_PORT in pc_link.h
BOARD_NAME = "mediahud.local"  # WiFi: the name the board announces on your network
UPDATE_EVERY = 0.5             # seconds between song checks
RESEND_EVERY = 2.0             # resend even if nothing changed, so the board knows we're alive
# These sizes must match the ones at the top of SpotifyHUD.ino
ART_W, ART_H = 130, 130        # album art
TXT_W, TXT_H = 440, 64         # song name + artist
COVER_SIZE = 80                # playlist covers
MAX_PLAYLISTS = 6
ROW_W, ROW_H = 440, 34         # one song in a playlist's song list
SONGS_PER_PAGE = 6
SONG_ICON = 30                 # little album cover next to each song
ICON_X = 36                    # where the icon sits in the row (the board puts it there)
SEARCH_LIST = -2               # list number the board uses for search results
CLK_W, CLK_H = 440, 170        # the clock picture (must match SpotifyHUD.ino)
CLOCK_24_HOUR = True           # True = 14:41, False = 2:41 pm
CLOCK_FONTS = ["segoeuib.ttf", "YuGothB.ttc", "arialbd.ttf"]
STRIP_W, STRIP_H = 448, 96     # the clock screen's bottom strip: last played + weather

# Weather for the clock screen (free, no account: open-meteo.com). Change to your city if you like.
WEATHER_LATITUDE = -33.87      # Sydney
WEATHER_LONGITUDE = 151.21
CHUNK = 16384                  # must match CHUNK in SpotifyHUD.ino
BACKGROUND = (0x12, 0x12, 0x12)
DEFAULT_BG = "121212"          # background colour when there's no album art

# Windows fonts that include Japanese (and English). The first one found is used.
FONTS_DIR = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
TITLE_FONTS = ["YuGothB.ttc", "meiryob.ttc", "meiryo.ttc", "msgothic.ttc", "segoeuib.ttf", "arialbd.ttf"]
ARTIST_FONTS = ["YuGothM.ttc", "meiryo.ttc", "msgothic.ttc", "segoeui.ttf", "arial.ttf"]
KOREAN_TITLE_FONTS = ["malgunbd.ttf", "malgun.ttf"]
KOREAN_ARTIST_FONTS = ["malgun.ttf"]

HERE = os.path.dirname(os.path.abspath(__file__))
PLAYLISTS_FILE = os.path.join(HERE, "playlists.txt")
BOARD_ADDRESS_FILE = os.path.join(HERE, "board_address.txt")   # the board's WiFi address, saved automatically
COVERS_DIR = os.path.join(HERE, "covers")   # downloaded playlist pictures are kept here
LOG_FILE = os.path.join(HERE, "helper_log.txt")
STARTUP_SHORTCUT = os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup",
                                "Spotify HUD helper.lnk")
SINGLE_INSTANCE_PORT = 47811   # only used to stop two copies running at once


class Control:
    """Shared between the main loop and the tray icon."""
    paused = False
    stop = False
    status = "Starting..."


# ------------------------------------------------------------------
#  USB connection to the board
# ------------------------------------------------------------------

class WifiLink:
    """The board over WiFi, with the same read/write/close as the USB serial port."""

    def __init__(self, host):
        self.sock = socket.create_connection((host, BOARD_PORT), timeout=2)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)   # send small messages at once
        self.sock.settimeout(3)

    def read(self, size):
        if not select.select([self.sock], [], [], 0)[0]:
            return b""
        try:
            data = self.sock.recv(size)
        except OSError as e:
            raise serial.SerialException(f"WiFi connection lost: {e}")
        if not data:
            raise serial.SerialException("the board closed the WiFi connection")
        return data

    def write(self, data):
        try:
            self.sock.sendall(data)
        except OSError as e:
            raise serial.SerialException(f"WiFi connection lost: {e}")

    def close(self):
        self.sock.close()


def find_board_on_network():
    """Check every address on this PC's home network(s) for the board (takes ~2 seconds)."""
    prefixes = set()
    try:
        if psutil:
            for addrs in psutil.net_if_addrs().values():
                for a in addrs:
                    if a.family == socket.AF_INET and not a.address.startswith(("127.", "169.254.")):
                        prefixes.add(a.address.rsplit(".", 1)[0])
        else:
            for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
                if not ip.startswith(("127.", "169.254.")):
                    prefixes.add(ip.rsplit(".", 1)[0])
    except OSError:
        pass

    def probe(ip):
        try:
            socket.create_connection((ip, BOARD_PORT), timeout=0.4).close()
            return ip
        except OSError:
            return None

    candidates = [f"{p}.{i}" for p in sorted(prefixes) for i in range(1, 255)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=64) as pool:
        for ip in pool.map(probe, candidates):
            if ip:
                return ip
    return None


def usb_port():
    return next((p.device for p in list_ports.comports() if p.vid == ESP32_USB_VENDOR_ID), None)


class Board:
    def __init__(self):
        self.ser = None
        self.kind = None          # "usb" or "wifi"
        self.last_scan = 0.0
        self.received = b""
        self.waiting_lines = []

    def try_connect(self):
        """One attempt to reach the board: USB cable first, then WiFi. Returns True if connected."""
        port = usb_port()
        if port is None:
            return self.try_wifi()
        try:
            ser = serial.Serial()
            ser.port = port
            ser.baudrate = 115200
            ser.timeout = 0
            ser.write_timeout = 2
            # Keep these low so opening the port doesn't reset the board.
            ser.dtr = False
            ser.rts = False
            ser.open()
        except serial.SerialException as e:
            self.say(f"Found the board on {port} but couldn't open it ({e}). "
                     "Is the Arduino Serial Monitor open, or another copy of this helper?")
            return False
        self._connected(ser, "usb", f"Connected to the board on {port} (USB)")
        return True

    def try_wifi(self):
        hosts = []
        if os.path.exists(BOARD_ADDRESS_FILE):
            with open(BOARD_ADDRESS_FILE) as f:
                saved = f.read().strip()
            if saved:
                hosts.append(saved)
        hosts.append(BOARD_NAME)
        for host in hosts:
            try:
                link = WifiLink(host)
            except OSError:
                continue
            self._connected(link, "wifi", f"Connected to the board over WiFi ({host})")
            return True
        # Not at the saved address (the router may have given it a new one): look for it.
        if time.time() - self.last_scan > 30:
            self.last_scan = time.time()
            found = find_board_on_network()
            if found:
                with open(BOARD_ADDRESS_FILE, "w") as f:
                    f.write(found)
                try:
                    self._connected(WifiLink(found), "wifi", f"Found the board at a new address: {found} (saved)")
                    return True
                except OSError:
                    pass
            hosts.append("searched the whole network")
        self.say(f"Looking for the board... tried USB and WiFi ({', '.join(hosts)}). "
                 "Plug in the USB cable, or check the board shows its WiFi address.")
        return False

    def _connected(self, link, kind, message):
        self.ser = link
        self.kind = kind
        self.received = b""
        self.waiting_lines = []
        self.say(message)

    def say(self, text):
        """Print a status message (only when it changes, so the log doesn't fill up)."""
        if text != Control.status:
            print(text)
            Control.status = text

    def close(self):
        try:
            self.ser.close()
        except Exception:
            pass
        self.ser = None
        self.kind = None

    def write(self, data):
        self.ser.write(data)

    def read_lines(self):
        """Return any complete lines the board has sent."""
        self.received += self.ser.read(4096)
        lines = self.waiting_lines
        self.waiting_lines = []
        while b"\n" in self.received:
            line, self.received = self.received.split(b"\n", 1)
            lines.append(line.decode("utf-8", errors="ignore").strip())
        return lines

    def wait_for_ack(self, timeout=2.0):
        """Wait for the board to say "ACK". Other lines (button presses) are kept for later."""
        end = time.time() + timeout
        while time.time() < end:
            lines = self.read_lines()
            if "ACK" in lines:
                lines.remove("ACK")
                self.waiting_lines.extend(lines)   # keep anything that came with it
                return True
            self.waiting_lines.extend(lines)
            time.sleep(0.002)
        return False


# ------------------------------------------------------------------
#  Windows media info
# ------------------------------------------------------------------

def clean(text):
    """Tabs and newlines would break our simple message format, so remove them."""
    return " ".join((text or "").replace("\t", " ").split())


def pick_session(manager):
    """Prefer Spotify; otherwise use whatever Windows says is playing."""
    for session in manager.get_sessions():
        if "spotify" in (session.source_app_user_model_id or "").lower():
            return session
    return manager.get_current_session()


async def read_thumbnail_bytes(props):
    """Get the album art file (usually a JPEG) that Windows has for this song."""
    ref = props.thumbnail if props else None
    if ref is None:
        return None
    stream = await ref.open_read_async()
    size = int(stream.size)
    if size == 0:
        return None
    buf = Buffer(size)
    result = await stream.read_async(buf, size, InputStreamOptions.READ_AHEAD)
    for candidate in (result, buf):
        try:
            return bytes(memoryview(candidate))[: candidate.length]
        except Exception:
            pass
    return None


def to_rgb565(img):
    """Convert a picture to the board's colour format (RGB565, 2 bytes per pixel)."""
    rgb = img.convert("RGB").tobytes()
    out = bytearray(len(rgb) // 3 * 2)
    for i in range(len(rgb) // 3):
        r, g, b = rgb[3 * i], rgb[3 * i + 1], rgb[3 * i + 2]
        v = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)
        out[2 * i] = v >> 8
        out[2 * i + 1] = v & 0xFF
    return bytes(out)


def art_pixels(image_bytes):
    """Shrink the album art to fit the board."""
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    return to_rgb565(ImageOps.fit(img, (ART_W, ART_H), Image.LANCZOS))


def background_colour(image_bytes):
    """Pick the album art's main colour, made dark enough that white text stays easy to read.
    Like Spotify's own app: prefers colourful parts over grey/black/white ones."""
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB").resize((48, 48))
    small = img.quantize(colors=6)
    palette = small.getpalette()
    best, best_score = None, -1.0
    for count, index in small.getcolors():
        r, g, b = palette[index * 3:index * 3 + 3]
        h, l, s = colorsys.rgb_to_hls(r / 255, g / 255, b / 255)
        score = count * (0.25 + s) * (1.0 if 0.12 < l < 0.88 else 0.3)
        if score > best_score:
            best, best_score = (h, l, s), score
    h, l, s = best
    r, g, b = colorsys.hls_to_rgb(h, 0.20, min(s, 0.55))
    return f"{int(r * 255):02X}{int(g * 255):02X}{int(b * 255):02X}"


_font_cache = {}

def load_font(names, size):
    for name in names:
        key = (name, size)
        if key not in _font_cache:
            try:
                _font_cache[key] = ImageFont.truetype(os.path.join(FONTS_DIR, name), size)
            except OSError:
                _font_cache[key] = None
        if _font_cache[key]:
            return _font_cache[key]
    return ImageFont.load_default(size)


def has_korean(text):
    return any("\uac00" <= ch <= "\ud7a3" or "\u1100" <= ch <= "\u11ff" for ch in text)


def fit(draw, text, font, max_width):
    """Cut the text short with "..." if it's too wide."""
    if draw.textlength(text, font=font) <= max_width:
        return text
    while text and draw.textlength(text + "…", font=font) > max_width:
        text = text[:-1]
    return text.rstrip() + "…"


def pack_grey(img):
    """Pack a greyscale picture into 4 bits per pixel (two pixels per byte, first in the top 4 bits).
    The board tints it white: brighter here = whiter on screen, black = see-through."""
    data = img.tobytes()
    if len(data) % 2:
        data += b"\0"
    out = bytearray(len(data) // 2)
    for i in range(0, len(data), 2):
        out[i // 2] = (data[i] >> 4) << 4 | (data[i + 1] >> 4)
    return bytes(out)


def text_pixels(title, artist):
    """Draw the song name and artist as a picture, using Windows' fonts (so Japanese works)."""
    korean = has_korean(title + artist)
    title_font = load_font(KOREAN_TITLE_FONTS if korean else TITLE_FONTS, 28)
    artist_font = load_font(KOREAN_ARTIST_FONTS if korean else ARTIST_FONTS, 20)

    img = Image.new("L", (TXT_W, TXT_H), 0)
    draw = ImageDraw.Draw(img)
    draw.text((TXT_W // 2, 0), fit(draw, title, title_font, TXT_W - 8),
              font=title_font, fill=255, anchor="mt")
    draw.text((TXT_W // 2, 40), fit(draw, artist, artist_font, TXT_W - 8),
              font=artist_font, fill=170, anchor="mt")
    return pack_grey(img)


def clock_pixels(now):
    """The clock screen: big time, with the date underneath."""
    img = Image.new("L", (CLK_W, CLK_H), 0)
    draw = ImageDraw.Draw(img)
    big = load_font(CLOCK_FONTS, 112)
    small = load_font(ARTIST_FONTS, 28)
    if CLOCK_24_HOUR:
        # Centre the digits by their actual drawn size, so every font lines up the same.
        text = now.strftime("%H:%M")
        left, top, right, bottom = draw.textbbox((0, 0), text, font=big)
        draw.text(((CLK_W - (right - left)) / 2 - left, 10 - top), text, font=big, fill=255)
        date_y = 10 + (bottom - top) + 22   # just under the digits
    else:
        time_text = now.strftime("%I:%M").lstrip("0")
        ampm = now.strftime("%p").lower()
        ampm_font = load_font(CLOCK_FONTS, 34)
        w = draw.textlength(time_text, font=big) + 10 + draw.textlength(ampm, font=ampm_font)
        x = (CLK_W - w) / 2
        draw.text((x, 0), time_text, font=big, fill=255, anchor="lt")
        x += draw.textlength(time_text, font=big) + 10
        draw.text((x, 92), ampm, font=ampm_font, fill=190, anchor="ls")
        date_y = 130
    date_text = f"{now:%A} {now.day} {now:%B}"
    draw.text((CLK_W // 2, date_y), date_text, font=small, fill=170, anchor="mt")
    return pack_grey(img)


WEATHER_CODES = {   # weather code -> (icon, words)
    0: ("sun", "Clear"), 1: ("sun", "Mostly clear"), 2: ("partly", "Partly cloudy"),
    3: ("cloud", "Cloudy"), 45: ("fog", "Fog"), 48: ("fog", "Fog"),
    51: ("rain", "Drizzle"), 53: ("rain", "Drizzle"), 55: ("rain", "Drizzle"),
    56: ("rain", "Icy drizzle"), 57: ("rain", "Icy drizzle"),
    61: ("rain", "Light rain"), 63: ("rain", "Rain"), 65: ("rain", "Heavy rain"),
    66: ("rain", "Icy rain"), 67: ("rain", "Icy rain"),
    71: ("snow", "Light snow"), 73: ("snow", "Snow"), 75: ("snow", "Heavy snow"), 77: ("snow", "Snow"),
    80: ("rain", "Showers"), 81: ("rain", "Showers"), 82: ("rain", "Heavy showers"),
    85: ("snow", "Snow showers"), 86: ("snow", "Snow showers"),
    95: ("storm", "Thunderstorm"), 96: ("storm", "Thunderstorm"), 99: ("storm", "Thunderstorm"),
}


def draw_weather_icon(draw, x, y, kind):
    """Draw a simple 40x40 weather icon with its top-left corner at (x, y)."""
    def sun(cx, cy, r, shade):
        for i in range(8):
            a = i * 3.14159 / 4
            draw.line((cx + (r + 3) * math.cos(a), cy + (r + 3) * math.sin(a),
                       cx + (r + 8) * math.cos(a), cy + (r + 8) * math.sin(a)), fill=shade, width=3)
        draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=shade)

    def cloud(cx, cy, shade):
        draw.ellipse((cx - 17, cy - 4, cx - 1, cy + 12), fill=shade)
        draw.ellipse((cx - 9, cy - 13, cx + 11, cy + 7), fill=shade)
        draw.ellipse((cx + 2, cy - 4, cx + 18, cy + 12), fill=shade)
        draw.rectangle((cx - 9, cy + 2, cx + 10, cy + 12), fill=shade)

    if kind == "sun":
        sun(x + 20, y + 20, 9, 240)
    elif kind == "partly":
        sun(x + 26, y + 13, 7, 200)
        cloud(x + 18, y + 24, 240)
    elif kind in ("cloud", "fog"):
        cloud(x + 20, y + 18, 220)
        if kind == "fog":
            for k in range(2):
                draw.line((x + 4, y + 34 + 5 * k, x + 36, y + 34 + 5 * k), fill=170, width=2)
    else:
        cloud(x + 20, y + 14, 220)
        for k in range(3):
            px = x + 10 + 10 * k
            if kind == "rain":
                draw.line((px, y + 30, px - 3, y + 38), fill=200, width=2)
            elif kind == "snow":
                draw.ellipse((px - 2, y + 31, px + 2, y + 35), fill=230)
        if kind == "storm":
            draw.polygon([(x + 22, y + 26), (x + 14, y + 36), (x + 20, y + 36), (x + 16, y + 44),
                          (x + 27, y + 32), (x + 21, y + 32)], fill=255)


class WeatherFetcher:
    """Checks the weather every 15 minutes in the background."""

    def __init__(self):
        self.now = None   # (symbol, words, temperature, high, low)
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        url = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
               "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min"
               "&timezone=auto&forecast_days=1" % (WEATHER_LATITUDE, WEATHER_LONGITUDE))
        while True:
            try:
                data = json.loads(CoverFetcher._download(url))
                code = data["current"]["weather_code"]
                symbol, words = WEATHER_CODES.get(code, ("cloud", ""))
                self.now = (symbol, words, round(data["current"]["temperature_2m"]),
                            round(data["daily"]["temperature_2m_max"][0]),
                            round(data["daily"]["temperature_2m_min"][0]))
                time.sleep(15 * 60)
            except Exception as e:
                print(f"  (couldn't get the weather: {e})")
                time.sleep(5 * 60)


def strip_pixels(last_played, weather):
    """The clock screen's bottom strip. Left: the last song (the board puts its cover and a
    Resume button there). Right: the weather."""
    img = Image.new("L", (STRIP_W, STRIP_H), 0)
    draw = ImageDraw.Draw(img)
    if last_played:
        title, artist = last_played
        korean = has_korean(title + artist)
        tfont = load_font(KOREAN_TITLE_FONTS if korean else TITLE_FONTS, 19)
        afont = load_font(KOREAN_ARTIST_FONTS if korean else ARTIST_FONTS, 15)
        x, width = 68, 210                 # right of the cover
        draw.text((x, 2), "LAST PLAYED", font=load_font(ARTIST_FONTS, 11), fill=110)
        draw.text((x, 16), fit(draw, title, tfont, width), font=tfont, fill=255)
        draw.text((x, 40), fit(draw, artist, afont, width), font=afont, fill=170)
    if weather:
        symbol, words, temp, high, low = weather
        right = STRIP_W - 4
        big = load_font(CLOCK_FONTS, 40)
        temp_text = f"{temp}\u00b0"
        tw = draw.textlength(temp_text, font=big)
        draw.text((right, 0), temp_text, font=big, fill=255, anchor="ra")
        draw_weather_icon(draw, right - tw - 48, 4, symbol)
        small = load_font(ARTIST_FONTS, 15)
        draw.text((right, 54), words, font=small, fill=190, anchor="ra")
        draw.text((right, 74), f"H {high}\u00b0   L {low}\u00b0", font=small, fill=150, anchor="ra")
    return pack_grey(img)


def pc_stats():
    if psutil is None:
        return ""
    cpu = psutil.cpu_percent(interval=None)
    ram = psutil.virtual_memory().percent
    return f"CPU {cpu:.0f}%   \u00b7   Memory {ram:.0f}%"


def send_picture(board, kind, pixels):
    """kind is "ART", "TXT", ... Sent in 16 KB pieces; the board says "ACK" after each."""
    board.write(f"IMG\t{kind}\n".encode())
    for start in range(0, len(pixels), CHUNK):
        board.write(pixels[start:start + CHUNK])
        if not board.wait_for_ack():
            print(f"  ({kind.lower()} picture didn't make it to the board - will retry."
                  " If this keeps happening, check Tools > PSRAM > OPI PSRAM in the Arduino IDE)")
            return False
    return True


# ------------------------------------------------------------------
#  Playlists
# ------------------------------------------------------------------

PLAYLIST_LINK = re.compile(r"(?:https?://open\.spotify\.com/(?:[a-z-]+/)?playlist/|spotify:playlist:)([A-Za-z0-9]+)")


def read_playlists():
    """Read playlists.txt. Each line: a name, then the playlist's Spotify link."""
    if not os.path.exists(PLAYLISTS_FILE):
        return []
    playlists = []
    with open(PLAYLISTS_FILE, encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            match = PLAYLIST_LINK.search(line)
            if not match:
                print(f"  (playlists.txt: no Spotify playlist link found in: {line})")
                continue
            name = clean(line[:match.start()].strip(" \t:|-"))
            playlists.append({"name": name or f"Playlist {len(playlists) + 1}", "id": match.group(1)})
    if len(playlists) > MAX_PLAYLISTS:
        print(f"  (playlists.txt has {len(playlists)} playlists - only the first {MAX_PLAYLISTS} fit on the board)")
        playlists = playlists[:MAX_PLAYLISTS]
    return playlists


class CoverFetcher:
    """Downloads playlist pictures in the background (using Spotify's public link-preview
    service, which doesn't need a login) and keeps a copy in the covers folder."""

    def __init__(self):
        self.ready = {}        # playlist id -> picture file bytes
        self.titles = {}       # playlist id -> the playlist's name on Spotify
        self.started = set()

    def get(self, playlist_id):
        if playlist_id in self.ready:
            return self.ready[playlist_id]
        if playlist_id not in self.started:
            self.started.add(playlist_id)
            threading.Thread(target=self._fetch, args=(playlist_id,), daemon=True).start()
        return None

    def _fetch(self, playlist_id):
        path = os.path.join(COVERS_DIR, playlist_id + ".jpg")
        info_path = os.path.join(COVERS_DIR, playlist_id + ".json")
        try:
            if os.path.exists(info_path):
                with open(info_path, encoding="utf-8") as f:
                    self.titles[playlist_id] = json.load(f).get("title", "")
            if not os.path.exists(path):
                link = "https://open.spotify.com/playlist/" + playlist_id
                info = json.loads(self._download("https://open.spotify.com/oembed?url=" + urllib.parse.quote(link, safe="")))
                os.makedirs(COVERS_DIR, exist_ok=True)
                with open(info_path, "w", encoding="utf-8") as f:
                    json.dump({"title": info.get("title", "")}, f)
                self.titles[playlist_id] = info.get("title", "")
                if not info.get("thumbnail_url"):
                    print(f"  (Spotify has no picture for playlist {playlist_id} - is it private?)")
                    return
                os.makedirs(COVERS_DIR, exist_ok=True)
                with open(path, "wb") as f:
                    f.write(self._download(info["thumbnail_url"]))
            with open(path, "rb") as f:
                self.ready[playlist_id] = f.read()
        except Exception as e:
            print(f"  (couldn't get the picture for playlist {playlist_id}: {e})")

    @staticmethod
    def _download(url):
        request = urllib.request.Request(url, headers={"User-Agent": "MediaHUD/1.0"})
        with urllib.request.urlopen(request, timeout=15) as response:
            return response.read()


def cover_pixels(image_bytes):
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    return to_rgb565(ImageOps.fit(img, (COVER_SIZE, COVER_SIZE), Image.LANCZOS))


class TrackFetcher:
    """Gets the list of songs in a playlist.
    Spotify's public embed page (no login) gives the first 100 songs. For bigger playlists the
    rest is read from the Spotify app on this PC, once per launch and only if the playlist's
    song count changed since last time. A saved copy is used straight away while that happens."""

    def __init__(self):
        self.ready = {}        # playlist id -> list of songs
        self.started = set()
        self.remote = None     # SpotifyRemote, for reading big playlists from the app
        self.names_for = lambda playlist_id: []

    def get(self, playlist_id):
        if playlist_id not in self.started:
            self.started.add(playlist_id)
            path = os.path.join(COVERS_DIR, playlist_id + "_songs.json")
            saved = self._load(path)
            if saved is not None:
                self.ready[playlist_id] = saved
            threading.Thread(target=self._fetch, args=(playlist_id, path), daemon=True).start()
        return self.ready.get(playlist_id)

    @staticmethod
    def _load(path):
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            return data["songs"] if isinstance(data, dict) else data
        except Exception:
            return None

    def _save(self, playlist_id, path, songs):
        os.makedirs(COVERS_DIR, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"songs": songs, "saved": time.strftime("%Y-%m-%d %H:%M")}, f, ensure_ascii=False)
        self.ready[playlist_id] = songs

    def _fetch(self, playlist_id, path):
        try:
            first = self._first_100(playlist_id)
        except Exception as e:
            print(f"  (couldn't get the songs of playlist {playlist_id}: {e})")
            first = None
        total = self._song_count(playlist_id)
        saved = self.ready.get(playlist_id)

        if first is not None and (len(first) < 100 or (total is not None and total <= len(first))):
            self._save(playlist_id, path, first)     # small playlist: the public page has every song
            return
        if first is None and saved is None:
            print(f"  (couldn't read the songs of playlist {playlist_id})")
            return
        complete = saved and all(song.get("uri") or "at" in song for song in saved)
        if complete and total and len(saved) == total and (not first or self._same_start(saved, first)):
            return                                   # big playlist, but nothing changed since last time
        if first and (not saved or len(saved) < len(first)):
            self.ready[playlist_id] = first          # show the first 100 meanwhile

        songs = self._read_from_app(playlist_id)
        if songs and len(songs) >= len(first or []):
            by_title = {}
            for song in first or saved or []:
                if song.get("uri"):
                    by_title.setdefault(simplify(song["title"]), song["uri"])
            for song in songs:
                song.pop("_row", None)
                song["title"], song["subtitle"] = clean(song["title"]), clean(song["subtitle"])
                if not song.get("uri"):
                    song["uri"] = by_title.get(simplify(song["title"]))
            missing = sum(1 for song in songs if not song.get("uri"))
            print(f"  playlist {playlist_id}: {len(songs)} songs" +
                  (f" ({missing} without a little picture)" if missing else ""))
            self._save(playlist_id, path, songs)
        elif first:
            if not saved or len(saved) <= len(first):
                self._save(playlist_id, path, first)
            print(f"  (playlist {playlist_id}: couldn't read it from the Spotify app - "
                  f"showing {len(self.ready[playlist_id])} songs)")

    def _first_100(self, playlist_id):
        page = CoverFetcher._download("https://open.spotify.com/embed/playlist/" + playlist_id).decode("utf-8", "ignore")
        m = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', page, re.S)
        tracks = self._find_tracks(json.loads(m.group(1))) if m else None
        if not tracks:
            return None
        return [{"title": clean(t.get("title")), "subtitle": clean(t.get("subtitle")), "uri": t.get("uri")}
                for t in tracks if t.get("uri", "").startswith("spotify:track:")]

    @staticmethod
    def _song_count(playlist_id):
        """How many songs the playlist has, from its public page ("... · 248 items · ..."). None if unknown."""
        try:
            page = CoverFetcher._download("https://open.spotify.com/playlist/" + playlist_id).decode("utf-8", "ignore")
            m = re.search(r'content="[^"]*?(\d[\d,.]*)\s*(?:items|songs)\b', page)
            return int(re.sub(r"[,.]", "", m.group(1))) if m else None
        except Exception:
            return None

    @staticmethod
    def _same_start(saved, first):
        a = [s.get("uri") for s in saved[:len(first)]]
        return a == [s.get("uri") for s in first]

    def _read_from_app(self, playlist_id):
        remote = self.remote
        if remote is None:
            return None
        waited = False
        while not remote.spotify_open():             # wait until you open Spotify
            if not waited:
                print("  (waiting for the Spotify app to open, to read the rest of a big playlist)")
                waited = True
            time.sleep(5)
        if not remote.available:
            return None
        done, result = threading.Event(), []
        remote.read_playlist(playlist_id, self.names_for(playlist_id),
                             lambda songs: (result.append(songs), done.set()))
        done.wait(300)
        return result[0] if result else None

    @classmethod
    def _find_tracks(cls, obj):
        if isinstance(obj, dict):
            if isinstance(obj.get("trackList"), list):
                return obj["trackList"]
            obj = list(obj.values())
        if isinstance(obj, list):
            for v in obj:
                found = cls._find_tracks(v)
                if found:
                    return found
        return None


def song_row_pixels(number, title, artist):
    """Draw one song row (number, title, artist) as a 4-bit greyscale picture.
    The board tints it white, so brighter = whiter: title bright, artist dimmer."""
    korean = has_korean(title + artist)
    title_font = load_font(KOREAN_TITLE_FONTS if korean else TITLE_FONTS, 18)
    small_font = load_font(KOREAN_ARTIST_FONTS if korean else ARTIST_FONTS, 15)

    img = Image.new("L", (ROW_W, ROW_H), 0)
    draw = ImageDraw.Draw(img)
    mid = ROW_H // 2
    draw.text((18, mid), str(number), font=small_font, fill=110, anchor="mm")
    x = ICON_X + SONG_ICON + 10   # leave room for the little album cover
    artist_w = min(draw.textlength(artist, font=small_font), 170) if artist else 0
    title = fit(draw, title, title_font, ROW_W - x - artist_w - 16)
    draw.text((x, mid), title, font=title_font, fill=255, anchor="lm")
    x += draw.textlength(title, font=title_font) + 12
    if artist:
        draw.text((x, mid), fit(draw, artist, small_font, ROW_W - x - 4), font=small_font, fill=140, anchor="lm")

    return pack_grey(img)


class SongIconFetcher:
    """Gets each song's album cover (small) from Spotify's public link-preview service,
    a few at a time, and keeps a copy in covers/songs so it's instant next time."""

    def __init__(self):
        self.ready = {}       # track uri -> picture file bytes
        self.started = set()
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=4)

    def get(self, uri):
        if uri in self.ready:
            return self.ready[uri]
        if uri not in self.started:
            self.started.add(uri)
            self.pool.submit(self._fetch, uri)
        return None

    def _fetch(self, uri):
        track_id = uri.split(":")[-1]
        path = os.path.join(COVERS_DIR, "songs", track_id + ".jpg")
        try:
            if not os.path.exists(path):
                link = "https://open.spotify.com/track/" + track_id
                info = json.loads(CoverFetcher._download("https://open.spotify.com/oembed?url=" + urllib.parse.quote(link, safe="")))
                if not info.get("thumbnail_url"):
                    return
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "wb") as f:
                    f.write(CoverFetcher._download(info["thumbnail_url"]))
            with open(path, "rb") as f:
                self.ready[uri] = f.read()
        except Exception as e:
            print(f"  (couldn't get the cover for {uri}: {e})")


def icon_pixels(image_bytes):
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    return to_rgb565(ImageOps.fit(img, (SONG_ICON, SONG_ICON), Image.LANCZOS))


def simplify(text):
    """For searching: ignore upper/lower case, accents and full-width letters."""
    text = unicodedata.normalize("NFKD", text or "").casefold()
    return "".join(ch for ch in text if not unicodedata.combining(ch))


def search_songs(query, playlists, songs_fetcher):
    """Find songs whose title or artist contains the query, across all playlists."""
    q = simplify(query).strip()
    results, seen = [], set()
    if not q:
        return results
    for pl_index, pl in enumerate(playlists):
        for song_index, song in enumerate(songs_fetcher.get(pl["id"]) or []):
            if q in simplify(song["title"]) or q in simplify(song["subtitle"]):
                key = song.get("uri") or (song["title"], song["subtitle"])
                if key not in seen:           # same song in two playlists: show it once
                    seen.add(key)
                    results.append((pl_index, song_index, song))
    return results


def find_in_playlist(query, songs):
    """Songs of one playlist matching the search: (song number, song)."""
    q = simplify(query).strip()
    if not q:
        return []
    return [(i, s) for i, s in enumerate(songs or []) if q in simplify(s["title"]) or q in simplify(s["subtitle"])]


def send_song_page(board, list_number, page, songs, numbers=None):
    """Send one page of a song list. Returns the songs on that page (for their icons).
    numbers: what number to show next to each song (default 1, 2, 3...)."""
    pages = max(1, (len(songs) + SONGS_PER_PAGE - 1) // SONGS_PER_PAGE)
    page = max(0, min(page, pages - 1))
    chunk = songs[page * SONGS_PER_PAGE:(page + 1) * SONGS_PER_PAGE]
    board.write(f"SL\t{list_number}\t{page}\t{pages}\t{len(chunk)}\n".encode())
    for k, song in enumerate(chunk):
        number = page * SONGS_PER_PAGE + k + 1
        if numbers:
            number = numbers[page * SONGS_PER_PAGE + k]
        if not send_picture(board, f"SR{k}", song_row_pixels(number, song["title"], song["subtitle"])):
            break
    return chunk


async def run_command(manager, command):
    session = pick_session(manager)
    if session is None:
        print(f"Got {command}, but nothing is playing.")
        return
    if command == "PLAYPAUSE":
        await session.try_toggle_play_pause_async()
    elif command == "NEXT":
        await session.try_skip_next_async()
    elif command == "PREV":
        await session.try_skip_previous_async()
    elif command == "SHUFFLE":
        info = session.get_playback_info()
        await session.try_change_shuffle_active_async(not bool(info.is_shuffle_active))
    elif command == "REPEAT" and RepeatMode is not None:
        current = session.get_playback_info().auto_repeat_mode
        order = [RepeatMode.NONE, RepeatMode.LIST, RepeatMode.TRACK]   # off -> all -> one song
        next_mode = order[(order.index(current) + 1) % 3] if current in order else RepeatMode.LIST
        await session.try_change_auto_repeat_mode_async(next_mode)
    elif command.startswith("SEEK\t") and command[5:].isdigit():
        await session.try_change_playback_position_async(int(command[5:]) * 10_000)   # ms -> 100ns units
    else:
        return
    print(f"Board pressed: {command}")


# ------------------------------------------------------------------
#  Main loop
# ------------------------------------------------------------------

async def main():
    manager = await MediaManager.request_async()
    board = Board()
    last_connect_try = 0.0

    last_message = ""
    last_sent_at = 0.0
    last_check_at = 0.0
    last_track = None
    art_checks = []          # times at which to (re)check the album art
    last_art_hash = None
    art_warning_shown = False

    playlists = read_playlists()
    playlists_changed_at = os.path.getmtime(PLAYLISTS_FILE) if os.path.exists(PLAYLISTS_FILE) else 0
    playlists_sent = False
    covers_sent = set()
    fetcher = CoverFetcher()
    songs_fetcher = TrackFetcher()
    remote = SpotifyRemote()
    songs_fetcher.remote = remote
    songs_fetcher.names_for = lambda pid: [fetcher.titles.get(pid, "")] + [p["name"] for p in playlists if p["id"] == pid]
    waiting_song_page = None   # (playlist number, page) the board asked for while songs were loading
    icons = SongIconFetcher()
    page_songs = []            # the songs on the page the board is showing (for their icons)
    icons_sent = set()
    search_results = []        # (playlist number, song number, song) from the last search
    search_numbers = None      # numbers to show next to search results (song numbers in the playlist)
    last_info = ""
    last_clock = None          # the minute the clock picture was last sent for
    last_strip = None          # what the clock's bottom strip last showed
    weather = WeatherFetcher()
    last_stats_at = 0.0
    last_modes = None
    like_results = []          # filled in by the Spotify thread after a LIKE
    last_timeline = None
    last_volume = None
    for pl in playlists:
        fetcher.get(pl["id"])   # start downloading pictures and song lists straight away
        songs_fetcher.get(pl["id"])
    print(f"Loaded {len(playlists)} playlists from playlists.txt")

    def reset():
        nonlocal last_message, last_track, last_art_hash, art_checks, playlists_sent, covers_sent
        nonlocal last_timeline, last_volume, last_clock, last_modes, last_strip
        last_message, last_track, last_art_hash, art_checks = "", None, None, []
        playlists_sent, covers_sent = False, set()
        page_songs.clear()
        last_timeline = last_volume = last_clock = last_modes = last_strip = None

    while not Control.stop:
        # Paused (e.g. while you upload code from the Arduino IDE): let go of the USB port.
        if Control.paused:
            if board.ser:
                board.close()
                reset()
            board.say("Paused - the USB port is free for uploading")
            await asyncio.sleep(0.3)
            continue

        # Not connected yet: try every 3 seconds.
        if board.ser is None:
            if time.time() - last_connect_try >= 3:
                last_connect_try = time.time()
                if board.try_connect():
                    reset()
            await asyncio.sleep(0.2)
            continue

        # On WiFi but the USB cable just got plugged in? Switch to USB (faster, always works).
        if board.kind == "wifi" and time.time() - last_connect_try >= 5:
            last_connect_try = time.time()
            if usb_port():
                board.say("USB cable found - switching from WiFi to USB")
                board.close()
                reset()
                continue

        try:
            # 1. Messages from the board
            for line in board.read_lines():
                if line == "HELLO":
                    reset()   # board (re)started - send everything again
                elif line in ("PLAYPAUSE", "NEXT", "PREV", "SHUFFLE", "REPEAT") or line.startswith("SEEK\t"):
                    await run_command(manager, line)
                    last_check_at = 0.0   # check the song again soon
                elif line == "LIKE":
                    print("Board: like this song")
                    remote.like_current_song(lambda result: like_results.append(result))
                elif line.startswith("SETVOL\t"):
                    parts = line.split("\t")
                    if len(parts) == 3 and parts[1] in ("pc", "spotify") and parts[2].isdigit():
                        remote.set_volume(parts[1], int(parts[2]))
                elif line.startswith("INFO\t"):
                    if line != last_info:
                        print("Board:", line[5:].replace("\t", ", "))
                        last_info = line
                        # Remember the board's WiFi address, to find it over WiFi later.
                        m = re.search(r"wifi=(\d+\.\d+\.\d+\.\d+)", line)
                        if m:
                            with open(BOARD_ADDRESS_FILE, "w") as f:
                                f.write(m.group(1))
                elif line.startswith("SEARCH\t"):
                    query = line[7:]
                    search_results = search_songs(query, playlists, songs_fetcher)
                    search_numbers = None
                    print(f"Board: search {query!r} - {len(search_results)} songs found")
                    page_songs[:] = send_song_page(board, SEARCH_LIST, 0, [r[2] for r in search_results])
                    icons_sent.clear()
                elif line.startswith("FIND\t"):
                    parts = line.split("\t", 2)
                    if len(parts) == 3 and parts[1].isdigit() and int(parts[1]) < len(playlists):
                        pl_index = int(parts[1])
                        found = find_in_playlist(parts[2], songs_fetcher.get(playlists[pl_index]["id"]))
                        search_results = [(pl_index, i, song) for i, song in found]
                        search_numbers = [i + 1 for i, _ in found]
                        print(f"Board: search {parts[2]!r} in {playlists[pl_index]['name']} - {len(found)} songs found")
                        page_songs[:] = send_song_page(board, SEARCH_LIST, 0, [r[2] for r in search_results], search_numbers)
                        icons_sent.clear()
                elif line.startswith("RESULTS\t") and line[8:].isdigit():
                    page_songs[:] = send_song_page(board, SEARCH_LIST, int(line[8:]), [r[2] for r in search_results], search_numbers)
                    icons_sent.clear()
                elif line.startswith("PLAYRESULT\t") and line[11:].isdigit():
                    i = int(line[11:])
                    if i < len(search_results):
                        pl_index, _, song = search_results[i]
                        print(f"Board: play song {song['title']} (from search)")
                        remote.play_song(playlists[pl_index]["id"], song)
                    last_check_at = 0.0
                elif line.startswith(("OPEN\t", "SONGS\t", "PLAYSONG\t")):
                    parts = line.split("\t")
                    numbers = [int(x) for x in parts[1:] if x.isdigit()]
                    if not numbers or not 0 <= numbers[0] < len(playlists):
                        continue
                    pl = playlists[numbers[0]]
                    songs = songs_fetcher.get(pl["id"])

                    if parts[0] == "OPEN":            # "Play all"
                        print(f"Board: play playlist {pl['name']}")
                        names = [fetcher.titles.get(pl["id"], ""), pl["name"]]
                        remote.play_playlist(pl["id"], names, songs[0] if songs else None)
                    elif parts[0] == "SONGS":         # show a page of songs
                        page = numbers[1] if len(numbers) > 1 else 0
                        if songs is None:
                            board.write(b"SLWAIT\n")
                            waiting_song_page = (numbers[0], page)
                        else:
                            page_songs[:] = send_song_page(board, numbers[0], page, songs)
                            icons_sent.clear()
                    elif parts[0] == "PLAYSONG" and songs and len(numbers) > 1 and numbers[1] < len(songs):
                        song = songs[numbers[1]]
                        print(f"Board: play song {song['title']} ({pl['name']})")
                        remote.play_song(pl["id"], song)
                    last_check_at = 0.0

            now = time.time()
            if now - last_check_at < UPDATE_EVERY:
                await asyncio.sleep(0.03)
                continue
            last_check_at = now

            # 2. Song info
            session = pick_session(manager)
            props = await session.try_get_media_properties_async() if session else None
            title = clean(props.title) if props else ""
            artist = clean(props.artist) if props else ""

            if session is None or (not title and not artist):
                message = "NONE\n"
                track = None
            else:
                info = session.get_playback_info()
                playing = "1" if info.playback_status == PlaybackStatus.PLAYING else "0"
                message = f"NP\t{playing}\t{title}\t{artist}\n"
                track = (title, artist)

            if message != last_message or now - last_sent_at >= RESEND_EVERY:
                board.write(message.encode("utf-8"))
                if message != last_message:
                    print("Now:", message.strip().replace("\t", " | "))
                last_message = message
                last_sent_at = now

            # Song position: "TL<tab>position ms<tab>length ms". The board counts up by itself
            # between updates, so we only send it when it jumps (new song, seek, pause...).
            if track:
                try:
                    tl = session.get_timeline_properties()
                    length = int(tl.end_time.total_seconds() * 1000)
                    position = tl.position.total_seconds() * 1000
                    updated = tl.last_updated_time
                    if playing == "1" and updated:
                        if updated.tzinfo is None:
                            updated = updated.replace(tzinfo=datetime.timezone.utc)
                        since = (datetime.datetime.now(datetime.timezone.utc) - updated).total_seconds()
                        if 0 <= since < 6 * 3600:   # ignore missing / nonsense times
                            position += since * 1000
                    position = int(max(0, min(position, length)))
                    expected = None
                    if last_timeline:
                        p0, l0, t0, was_playing = last_timeline
                        expected = p0 + ((now - t0) * 1000 if was_playing else 0)
                    if (last_timeline is None or l0 != length or abs(expected - position) > 1500
                            or was_playing != (playing == "1") or now - t0 > 10):
                        board.write(f"TL\t{position}\t{length}\n".encode())
                        last_timeline = (position, length, now, playing == "1")
                except Exception:
                    pass

            # Shuffle / repeat: "MODES<tab>shuffle<tab>repeat"
            #   shuffle: 1 on, 0 off, -1 not available.  repeat: 0 off, 1 all, 2 one song, -1 not available
            if track:
                shuffle, repeat = -1, -1
                try:
                    info = session.get_playback_info()
                    if info.controls.is_shuffle_enabled:
                        shuffle = 1 if info.is_shuffle_active else 0
                    if RepeatMode is not None and info.controls.is_repeat_enabled:
                        repeat = {RepeatMode.NONE: 0, RepeatMode.LIST: 1, RepeatMode.TRACK: 2}.get(info.auto_repeat_mode, 0)
                except Exception:
                    pass
                if (shuffle, repeat) != last_modes:
                    board.write(f"MODES\t{shuffle}\t{repeat}\n".encode())
                    last_modes = (shuffle, repeat)
            while like_results:
                board.write(f"LIKED\t{like_results.pop(0)}\n".encode())

            # Clock picture (once a minute) and PC stats (every few seconds)
            clock_now = datetime.datetime.now()
            if clock_now.strftime("%Y%m%d%H%M") != last_clock:
                if send_picture(board, "CLK", clock_pixels(clock_now)):
                    last_clock = clock_now.strftime("%Y%m%d%H%M")
            strip = (track, weather.now)   # last played = the paused song (None if Spotify's closed)
            if strip != last_strip:
                if send_picture(board, "CLB", strip_pixels(track, weather.now)):
                    last_strip = strip
            if now - last_stats_at > 3:
                last_stats_at = now
                stats = pc_stats()
                if stats:
                    board.write(f"STATS\t{stats}\n".encode())

            # Volume: "VOL<tab>pc<tab>spotify" (0-100, or -1 if unknown)
            volume = (remote.volume["pc"], remote.volume["spotify"])
            if volume != last_volume:
                board.write(f"VOL\t{volume[0]}\t{volume[1]}\n".encode())
                last_volume = volume

            if waiting_song_page and waiting_song_page[0] < len(playlists):
                songs = songs_fetcher.get(playlists[waiting_song_page[0]]["id"])
                if songs is not None:
                    page_songs[:] = send_song_page(board, waiting_song_page[0], waiting_song_page[1], songs)
                    icons_sent.clear()
                    waiting_song_page = None

            # Little album covers for the songs on the page the board is showing
            for k, song in enumerate(page_songs):
                if k in icons_sent:
                    continue
                if not song.get("uri"):
                    icons_sent.add(k)   # no Spotify ID for this song - it keeps the grey square
                    continue
                picture = icons.get(song["uri"])
                if picture is None:
                    continue
                try:
                    ok = send_picture(board, f"SI{k}", icon_pixels(picture))
                except Exception:
                    ok = True   # unreadable picture - skip it
                if ok:
                    icons_sent.add(k)

            # 3. Playlists - send the list (and again if playlists.txt is edited),
            #    then one cover picture at a time as they finish downloading.
            changed_at = os.path.getmtime(PLAYLISTS_FILE) if os.path.exists(PLAYLISTS_FILE) else 0
            if changed_at != playlists_changed_at:
                playlists_changed_at = changed_at
                playlists = read_playlists()
                print(f"playlists.txt changed - now {len(playlists)} playlists")
                for pl in playlists:
                    fetcher.get(pl["id"])
                    songs_fetcher.get(pl["id"])
                playlists_sent = False
            if not playlists_sent:
                board.write(b"PLCLEAR\n")
                for i, pl in enumerate(playlists):
                    board.write(f"PL\t{i}\t{pl['name']}\n".encode("utf-8"))
                playlists_sent, covers_sent = True, set()
            for i, pl in enumerate(playlists):
                if i in covers_sent:
                    continue
                picture = fetcher.get(pl["id"])
                if picture is None:
                    continue   # still downloading (or failed) - try again later
                try:
                    pixels = cover_pixels(picture)
                except Exception as e:
                    print(f"  (picture for {pl['name']} isn't readable: {e})")
                    covers_sent.add(i)
                    continue
                if send_picture(board, f"PL{i}", pixels):
                    covers_sent.add(i)
                break   # one picture per round keeps the buttons responsive

            # 4. Album art - check when the song changes, and again a bit later
            #    (Windows sometimes updates the picture a moment after the title).
            if track != last_track:
                last_track = track
                if track and not send_picture(board, "TXT", text_pixels(title, artist)):
                    last_track = None   # try again next time
                art_checks = [now, now + 1.5, now + 4.0] if track else []
                if not track:
                    last_art_hash = None
            if art_checks and now >= art_checks[0]:
                art_checks.pop(0)
                try:
                    image_bytes = await read_thumbnail_bytes(props)
                except Exception as e:
                    image_bytes = None
                    if not art_warning_shown:
                        print(f"  (couldn't read album art: {e})")
                        art_warning_shown = True
                art_hash = hashlib.md5(image_bytes).hexdigest() if image_bytes else "none"
                if art_hash != last_art_hash:
                    if image_bytes:
                        try:
                            pixels = art_pixels(image_bytes)
                        except Exception as e:   # not a picture Pillow can open
                            print(f"  (album art isn't a picture I can read: {e})")
                            pixels = None
                        if pixels is None:
                            board.write(f"NOART\nBG\t{DEFAULT_BG}\n".encode())
                            last_art_hash = art_hash
                        elif send_picture(board, "ART", pixels):
                            last_art_hash = art_hash
                            try:
                                board.write(f"BG\t{background_colour(image_bytes)}\n".encode())
                            except Exception:
                                board.write(f"BG\t{DEFAULT_BG}\n".encode())
                    elif not art_checks:   # still nothing after the last check
                        board.write(f"NOART\nBG\t{DEFAULT_BG}\n".encode())
                        last_art_hash = art_hash

        except serial.SerialException:
            board.say("Lost the board - reconnecting...")
            board.close()
            reset()

        await asyncio.sleep(0.03)

    board.close()


# ------------------------------------------------------------------
#  Starting with Windows, the tray icon, and only-one-copy
# ------------------------------------------------------------------

def pythonw_path():
    """pythonw.exe runs Python without a black window."""
    folder = os.path.dirname(sys.executable)
    candidate = os.path.join(folder, "pythonw.exe")
    return candidate if os.path.exists(candidate) else sys.executable


def install_autostart():
    def q(text):   # quote for PowerShell
        return "'" + text.replace("'", "''") + "'"
    script = os.path.abspath(__file__)
    ps = ("$s = (New-Object -ComObject WScript.Shell).CreateShortcut(" + q(STARTUP_SHORTCUT) + "); "
          "$s.TargetPath = " + q(pythonw_path()) + "; "
          "$s.Arguments = " + q('"' + script + '"') + "; "
          "$s.WorkingDirectory = " + q(HERE) + "; "
          "$s.Description = 'Spotify HUD helper'; $s.Save()")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True)
    print("Done! The helper will now start by itself when you log in to Windows.")


def remove_autostart():
    if os.path.exists(STARTUP_SHORTCUT):
        os.remove(STARTUP_SHORTCUT)
        print("Done. The helper won't start by itself any more.")
    else:
        print("It wasn't set to start automatically, so nothing to do.")


def claim_single_instance():
    """Returns a socket that stays open while we run, or None if another copy is already running."""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", SINGLE_INSTANCE_PORT))
        s.listen(1)
        return s
    except OSError:
        s.close()
        return None


def make_icon_image():
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((2, 2, 62, 62), fill=(0x1D, 0xB9, 0x54))
    d.ellipse((18, 38, 32, 50), fill="black")          # a little music note
    d.rectangle((28, 14, 32, 44), fill="black")
    d.polygon([(32, 14), (46, 20), (46, 26), (32, 20)], fill="black")
    return img


def start_tray_icon():
    if pystray is None:
        print("(Tip: 'pip install pystray' to get an icon by the clock.)")
        return None

    def toggle_pause(icon, item):
        Control.paused = not Control.paused

    def open_log(icon, item):
        if os.path.exists(LOG_FILE):
            os.startfile(LOG_FILE)

    def quit_helper(icon, item):
        Control.stop = True
        icon.stop()

    menu = pystray.Menu(
        pystray.MenuItem(lambda item: Control.status[:60], None, enabled=False),
        pystray.MenuItem("Pause (to upload code)", toggle_pause, checked=lambda item: Control.paused),
        pystray.MenuItem("Open log", open_log),
        pystray.MenuItem("Quit", quit_helper),
    )
    icon = pystray.Icon("MediaHUD", make_icon_image(), "Spotify HUD helper", menu)
    threading.Thread(target=icon.run, daemon=True).start()
    return icon


if __name__ == "__main__":
    if "--install" in sys.argv:
        install_autostart()
        sys.exit()
    if "--uninstall" in sys.argv:
        remove_autostart()
        sys.exit()

    # Started with pythonw (no window)? Then write messages to a log file instead.
    if sys.stdout is None:
        sys.stdout = sys.stderr = open(LOG_FILE, "w", encoding="utf-8", buffering=1)

    lock = claim_single_instance()
    if lock is None:
        print("The helper is already running (look for the green icon by the clock).")
        sys.exit()

    print(time.strftime("%Y-%m-%d %H:%M:%S"), "- Spotify helper running.",
          "Press Ctrl+C to stop." if sys.stdin and sys.stdin.isatty() else "")
    icon = start_tray_icon()
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    if icon:
        icon.stop()
    print("Stopped.")
